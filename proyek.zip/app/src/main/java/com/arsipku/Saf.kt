package com.arsipku

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.DocumentsContract.Document
import java.io.File

object Saf {
    private const val AUTH = "com.android.externalstorage.documents"
    val initial: Uri get() = DocumentsContract.buildTreeDocumentUri(AUTH, "primary:Android/data")

    private val cols = arrayOf(
        Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
        Document.COLUMN_SIZE, Document.COLUMN_LAST_MODIFIED
    )

    fun docUri(tree: Uri, id: String): Uri = DocumentsContract.buildDocumentUriUsingTree(tree, id)

    fun list(cr: ContentResolver, tree: Uri, docId: String): List<Node> {
        val uri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
        val out = ArrayList<Node>()
        cr.query(uri, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val dir = c.getString(2) == Document.MIME_TYPE_DIR
                val size = if (dir || c.isNull(3)) 0L else c.getLong(3)
                val time = if (c.isNull(4)) 0L else c.getLong(4)
                out.add(Node(c.getString(1), dir, size, time, c.getString(0)))
            }
        }
        return out.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    fun copyOut(cr: ContentResolver, tree: Uri, n: Node, dest: File) {
        val t = File(dest, n.name)
        if (n.isDir) {
            t.mkdirs()
            list(cr, tree, n.id).forEach { copyOut(cr, tree, it, t) }
        } else {
            val ins = cr.openInputStream(docUri(tree, n.id)) ?: error("Tidak bisa membaca ${n.name}")
            ins.use { i -> t.outputStream().use { o -> i.copyTo(o) } }
        }
    }

    fun copyIn(cr: ContentResolver, tree: Uri, parentId: String, f: File) {
        val parent = docUri(tree, parentId)
        if (f.isDirectory) {
            val d = DocumentsContract.createDocument(cr, parent, Document.MIME_TYPE_DIR, f.name) ?: error("Gagal membuat folder ${f.name}")
            val did = DocumentsContract.getDocumentId(d)
            f.listFiles()?.forEach { copyIn(cr, tree, did, it) }
        } else {
            val d = DocumentsContract.createDocument(cr, parent, "application/octet-stream", f.name) ?: error("Gagal membuat ${f.name}")
            val out = cr.openOutputStream(d) ?: error("Tidak bisa menulis ${f.name}")
            out.use { o -> f.inputStream().use { it.copyTo(o) } }
        }
    }

    fun delete(cr: ContentResolver, tree: Uri, n: Node) {
        DocumentsContract.deleteDocument(cr, docUri(tree, n.id))
    }
}
