package com.arsipku

import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.File

object FileOps {
    val exts = listOf(".zip", ".7z", ".tar", ".tar.gz", ".tgz", ".apk", ".jar")
    fun isArchive(f: File) = f.isFile && f.name.lowercase().let { n -> exts.any { n.endsWith(it) } }

    private fun target(src: File, dir: File): File {
        var t = File(dir, src.name)
        var i = 1
        while (t.exists()) {
            val ext = if (src.isFile && src.extension.isNotEmpty()) "." + src.extension else ""
            val base = if (ext.isEmpty()) src.name else src.name.removeSuffix(ext)
            t = File(dir, "$base ($i)$ext"); i++
        }
        return t
    }

    private fun inside(src: File, dir: File) =
        (dir.canonicalPath + "/").startsWith(src.canonicalPath + "/") && src.isDirectory

    fun copy(src: File, dir: File) {
        check(!inside(src, dir)) { "Folder tidak bisa disalin ke dalam dirinya sendiri" }
        check(src.copyRecursively(target(src, dir))) { "Gagal menyalin ${src.name}" }
    }

    fun move(src: File, dir: File) {
        check(!inside(src, dir)) { "Folder tidak bisa dipindah ke dalam dirinya sendiri" }
        if (src.parentFile?.canonicalPath == dir.canonicalPath) return
        val t = target(src, dir)
        if (!src.renameTo(t)) {
            check(src.copyRecursively(t)) { "Gagal memindah ${src.name}" }
            src.deleteRecursively()
        }
    }

    fun zip(files: List<File>, out: File, pass: String?) {
        out.delete()
        val p = ZipParameters()
        val usePass = !pass.isNullOrEmpty()
        if (usePass) { p.isEncryptFiles = true; p.encryptionMethod = EncryptionMethod.AES }
        val z = if (usePass) ZipFile(out, pass!!.toCharArray()) else ZipFile(out)
        files.forEach { if (it.isDirectory) z.addFolder(it, p) else z.addFile(it, p) }
    }

    private fun safe(dir: File, name: String): File {
        val f = File(dir, name)
        if (!f.canonicalPath.startsWith(dir.canonicalPath + File.separator)) throw SecurityException("Path berbahaya di arsip")
        return f
    }

    fun extract(arc: File, dir: File, pass: String?) {
        dir.mkdirs()
        val n = arc.name.lowercase()
        when {
            n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".jar") -> {
                val z = if (pass.isNullOrEmpty()) ZipFile(arc) else ZipFile(arc, pass.toCharArray())
                z.extractAll(dir.path)
            }
            n.endsWith(".7z") -> SevenZFile(arc).use { s ->
                while (true) {
                    val e = s.nextEntry ?: break
                    val o = safe(dir, e.name)
                    if (e.isDirectory) o.mkdirs() else {
                        o.parentFile?.mkdirs()
                        o.outputStream().use { out ->
                            val b = ByteArray(8192)
                            while (true) { val r = s.read(b); if (r < 0) break; out.write(b, 0, r) }
                        }
                    }
                }
            }
            n.endsWith(".tar") || n.endsWith(".tar.gz") || n.endsWith(".tgz") -> {
                val raw = arc.inputStream().buffered()
                val ins = if (n.endsWith(".tar")) raw else GzipCompressorInputStream(raw)
                TarArchiveInputStream(ins).use { t ->
                    while (true) {
                        val e = t.nextTarEntry ?: break
                        val o = safe(dir, e.name)
                        if (e.isDirectory) o.mkdirs() else {
                            o.parentFile?.mkdirs()
                            o.outputStream().use { t.copyTo(it) }
                        }
                    }
                }
            }
            else -> throw IllegalArgumentException("Format belum didukung")
        }
    }
}
