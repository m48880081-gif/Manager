package com.arsipku

import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterInputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object FileOps {
    val exts = listOf(".zip", ".7z", ".tar", ".tar.gz", ".tgz", ".apk", ".jar")
    fun isArcName(n: String) = n.lowercase().let { l -> exts.any { l.endsWith(it) } }
    fun isArchive(f: File) = f.isFile && isArcName(f.name)
    fun isZipLike(f: File) = f.name.lowercase().let { it.endsWith(".zip") || it.endsWith(".apk") || it.endsWith(".jar") }

    private fun target(src: File, dir: File): File {
        var t = File(dir, src.name)
        var i = 1
        while (t.exists()) {
            val ext = if (src.isFile && src.extension.isNotEmpty()) "." + src.extension else ""
            val base = if (ext.isEmpty()) src.name else src.name.removeSuffix(ext)
            t = File(dir, "$base ($i)$ext"); i++
        }
        return t
    }

    private fun inside(src: File, dir: File) =
        (dir.canonicalPath + "/").startsWith(src.canonicalPath + "/") && src.isDirectory

    fun copy(src: File, dir: File) {
        check(!inside(src, dir)) { "Folder tidak bisa disalin ke dalam dirinya sendiri" }
        check(src.copyRecursively(target(src, dir))) { "Gagal menyalin ${src.name}" }
    }

    fun move(src: File, dir: File) {
        check(!inside(src, dir)) { "Folder tidak bisa dipindah ke dalam dirinya sendiri" }
        if (src.parentFile?.canonicalPath == dir.canonicalPath) return
        val t = target(src, dir)
        if (!src.renameTo(t)) {
            check(src.copyRecursively(t)) { "Gagal memindah ${src.name}" }
            src.deleteRecursively()
        }
    }

    fun zip(files: List<File>, out: File, pass: String?) {
        out.delete()
        val p = ZipParameters()
        val usePass = !pass.isNullOrEmpty()
        if (usePass) { p.isEncryptFiles = true; p.encryptionMethod = EncryptionMethod.AES }
        val z = if (usePass) ZipFile(out, pass!!.toCharArray()) else ZipFile(out)
        files.forEach { if (it.isDirectory) z.addFolder(it, p) else z.addFile(it, p) }
    }

    private fun safe(dir: File, name: String): File {
        val f = File(dir, name)
        if (!f.canonicalPath.startsWith(dir.canonicalPath + File.separator)) throw SecurityException("Path berbahaya di arsip")
        return f
    }

    private class NoClose(i: InputStream) : FilterInputStream(i) { override fun close() {} }

    fun forEntries(arc: File, pass: String?, visit: (Entry, () -> InputStream) -> Unit) {
        val n = arc.name.lowercase()
        when {
            n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".jar") -> {
                val z = if (pass.isNullOrEmpty()) ZipFile(arc) else ZipFile(arc, pass.toCharArray())
                z.use { zf ->
                    for (h in zf.fileHeaders) {
                        visit(Entry(h.fileName.trimEnd('/'), h.isDirectory, h.uncompressedSize, h.lastModifiedTimeEpoch)) { zf.getInputStream(h) }
                    }
                }
            }
            n.endsWith(".7z") -> SevenZFile(arc).use { s ->
                val src = object : InputStream() {
                    override fun read(): Int = s.read()
                    override fun read(b: ByteArray, off: Int, len: Int): Int = s.read(b, off, len)
                }
                while (true) {
                    val e = s.nextEntry ?: break
                    val t = if (e.hasLastModifiedDate) e.lastModifiedDate.time else 0L
                    visit(Entry(e.name.trimEnd('/'), e.isDirectory, e.size, t)) { src }
                }
            }
            n.endsWith(".tar") || n.endsWith(".tar.gz") || n.endsWith(".tgz") -> {
                val raw = arc.inputStream().buffered()
                val ins = if (n.endsWith(".tar")) raw else GzipCompressorInputStream(raw)
                TarArchiveInputStream(ins).use { t ->
                    while (true) {
                        val e = t.nextTarEntry ?: break
                        visit(Entry(e.name.trimEnd('/'), e.isDirectory, e.size, e.modTime.time)) { NoClose(t) }
                    }
                }
            }
            else -> throw IllegalArgumentException("Format belum didukung")
        }
    }

    fun list(arc: File, pass: String?): List<Entry> {
        val out = ArrayList<Entry>()
        forEntries(arc, pass) { e, _ -> out.add(e) }
        return out
    }

    fun children(all: List<Entry>, inner: String): List<Node> {
        val m = LinkedHashMap<String, Node>()
        for (e in all) {
            if (!e.path.startsWith(inner)) continue
            val rest = e.path.substring(inner.length)
            if (rest.isEmpty()) continue
            val first = rest.substringBefore('/')
            val isDir = e.dir || rest.contains('/')
            val old = m[first]
            if (old == null || (!old.isDir && isDir)) {
                m[first] = Node(first, isDir, if (isDir) 0L else e.size, e.time, inner + first)
            }
        }
        return m.values.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    fun extractFrom(arc: File, pass: String?, ids: Set<String>, base: String, dest: File) {
        dest.mkdirs()
        forEntries(arc, pass) { e, open ->
            if (ids.any { e.path == it || e.path.startsWith("$it/") }) {
                val o = safe(dest, e.path.removePrefix(base))
                if (e.dir) o.mkdirs() else {
                    o.parentFile?.mkdirs()
                    val i = open()
                    try { o.outputStream().use { out -> i.copyTo(out) } } finally { i.close() }
                }
            }
        }
    }

    fun extract(arc: File, dir: File, pass: String?) {
        dir.mkdirs()
        val n = arc.name.lowercase()
        if (n.endsWith(".zip") || n.endsWith(".apk") || n.endsWith(".jar")) {
            val z = if (pass.isNullOrEmpty()) ZipFile(arc) else ZipFile(arc, pass.toCharArray())
            z.extractAll(dir.path)
        } else {
            forEntries(arc, pass) { e, open ->
                val o = safe(dir, e.path)
                if (e.dir) o.mkdirs() else {
                    o.parentFile?.mkdirs()
                    val i = open()
                    try { o.outputStream().use { out -> i.copyTo(out) } } finally { i.close() }
                }
            }
        }
    }

    fun collectAdds(files: List<File>, inner: String): Map<String, File> {
        val m = LinkedHashMap<String, File>()
        for (f in files) {
            if (f.isDirectory) {
                f.walkTopDown().filter { it.isFile }.forEach { m[inner + f.name + "/" + it.relativeTo(f).path.replace('\\', '/')] = it }
            } else m[inner + f.name] = f
        }
        return m
    }

    private class Counting(private val o: OutputStream) : OutputStream() {
        var n = 0L
        override fun write(b: Int) { o.write(b); n++ }
        override fun write(b: ByteArray, off: Int, len: Int) { o.write(b, off, len); n += len }
        override fun flush() = o.flush()
        override fun close() = o.close()
    }

    private val sigRe = Regex("META-INF/([^/]+\\.(SF|RSA|DSA|EC)|MANIFEST\\.MF)", RegexOption.IGNORE_CASE)
    private const val MIN_TIME = 347155200000L

    // Tulis ulang ZIP/APK: hapus entri, tambah file, rata 4-byte untuk entri STORED (seperti zipalign)
    fun rewriteZip(src: File, dst: File, drop: Set<String>, adds: Map<String, File>, stripSig: Boolean) {
        java.util.zip.ZipFile(src).use { zf ->
            val cnt = Counting(BufferedOutputStream(FileOutputStream(dst), 1 shl 16))
            ZipOutputStream(cnt).use { zo ->
                for (e in zf.entries().toList()) {
                    val name = e.name
                    val plain = name.trimEnd('/')
                    if (drop.any { plain == it || plain.startsWith("$it/") }) continue
                    if (adds.containsKey(plain)) continue
                    if (stripSig && sigRe.matches(name)) continue
                    val ze = ZipEntry(name)
                    ze.time = maxOf(e.time, MIN_TIME)
                    if (e.method == ZipEntry.STORED) {
                        ze.method = ZipEntry.STORED
                        ze.size = e.size; ze.compressedSize = e.size; ze.crc = e.crc
                        val align = if (name.endsWith(".so")) 16384L else 4L
                        val start = cnt.n + 30 + name.toByteArray(Charsets.UTF_8).size
                        var pad = ((align - start % align) % align).toInt()
                        if (pad in 1..3) pad += align.toInt()
                        if (pad > 0) {
                            val ex = ByteArray(pad)
                            ex[0] = 0x35; ex[1] = 0xD9.toByte()
                            ex[2] = (pad - 4).toByte(); ex[3] = ((pad - 4) shr 8).toByte()
                            ze.extra = ex
                        }
                    }
                    zo.putNextEntry(ze)
                    if (!e.isDirectory) zf.getInputStream(e).use { it.copyTo(zo) }
                    zo.closeEntry()
                }
                for ((n, f) in adds) {
                    val ze = ZipEntry(n)
                    ze.time = maxOf(f.lastModified(), MIN_TIME)
                    zo.putNextEntry(ze)
                    f.inputStream().use { it.copyTo(zo) }
                    zo.closeEntry()
                }
            }
        }
    }

    // Clone APK: ganti nama paket (dan label) di manifest, lalu tanda tangani dengan kunci Arsipku
    fun cloneApk(src: File, out: File, newPkg: String, newLabel: String?, filesDir: File) {
        val manifest = java.util.zip.ZipFile(src).use { zf ->
            val e = zf.getEntry("AndroidManifest.xml") ?: throw IllegalStateException("AndroidManifest.xml tidak ditemukan")
            zf.getInputStream(e).use { it.readBytes() }
        }
        val mf = File(filesDir, "AndroidManifest.xml")
        mf.writeBytes(AxmlPatcher.patch(manifest, newPkg, newLabel))
        val tmp = File(out.parentFile, out.name + ".tmp")
        try {
            rewriteZip(src, tmp, emptySet(), mapOf("AndroidManifest.xml" to mf), true)
            Signer.sign(tmp, out, Signer.defaultKeystore(filesDir), Signer.PASS, "", true, true, true)
        } finally { tmp.delete(); mf.delete() }
    }

    private fun replace(from: File, to: File) {
        if (!from.renameTo(to)) { from.copyTo(to, true); from.delete() }
    }

    // Ubah isi ZIP/APK. Kalau APK: otomatis ditandatangani ulang dengan kunci Arsipku.
    fun editZip(arc: File, drop: Set<String>, adds: Map<String, File>, filesDir: File) {
        val apk = arc.name.endsWith(".apk", true)
        val tmp = File(arc.parentFile, arc.name + ".tmp")
        try {
            rewriteZip(arc, tmp, drop, adds, apk)
            if (apk) {
                val out = File(arc.parentFile, arc.name + ".new")
                try {
                    Signer.sign(tmp, out, Signer.defaultKeystore(filesDir), Signer.PASS, "", true, true, true)
                } catch (e: Throwable) { out.delete(); throw e }
                replace(out, arc)
            } else replace(tmp, arc)
        } finally { tmp.delete() }
    }
}
