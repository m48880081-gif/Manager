package com.arsipku

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction

// ---------- Jenis file ----------

enum class Kind { TEXT, IMAGE, HTML, OTHER, UNKNOWN }
enum class How { TEXT, IMAGE, WEB, EXTERNAL }

private val imgExt = setOf("png", "jpg", "jpeg", "gif", "webp", "bmp")
private val htmlExt = setOf("html", "htm", "xhtml")
private val textExt = setOf(
    "txt", "md", "markdown", "log", "csv", "tsv", "json", "jsonl", "xml", "yml", "yaml", "toml", "ini", "cfg", "conf",
    "properties", "py", "js", "mjs", "ts", "jsx", "tsx", "css", "scss", "less", "java", "kt", "kts", "gradle", "c", "h",
    "cpp", "hpp", "cc", "cs", "go", "rs", "rb", "php", "sh", "bash", "zsh", "bat", "cmd", "ps1", "sql", "lua", "pl", "r",
    "swift", "dart", "vue", "svg", "srt", "vtt", "gitignore", "gitattributes", "env", "editorconfig", "pro", "smali",
    "lock", "tex", "rst", "org", "diff", "patch"
)
private val textNames = setOf("makefile", "dockerfile", "readme", "license", "changelog", "gemfile", "procfile", "gradlew", "cname")
private val otherExt = setOf(
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "ods", "odp", "rtf", "epub", "mp3", "mp4", "mkv", "avi",
    "mov", "wav", "ogg", "m4a", "flac", "aac", "3gp", "webm", "mpg", "wmv", "heic", "heif", "ico", "rar", "gz", "xz",
    "bz2", "iso", "dex", "so", "ttf", "otf", "apks", "xapk", "aab"
)

fun kindOf(name: String): Kind {
    val n = name.lowercase()
    val ext = n.substringAfterLast('.', "")
    return when {
        ext in imgExt -> Kind.IMAGE
        ext in htmlExt -> Kind.HTML
        ext in textExt || n in textNames -> Kind.TEXT
        ext in otherExt -> Kind.OTHER
        else -> Kind.UNKNOWN
    }
}

// ---------- Penampil ----------

class TextSrc(val file: File, val origin: Loc, val node: Node)

sealed class Viewer {
    class Edit(val src: TextSrc) : Viewer()
    class Photo(val file: File) : Viewer()
    class Web(val file: File, val back: Viewer? = null) : Viewer()
}

private const val MAX_TEXT = 2L * 1024 * 1024

// ---------- Buka lewat aplikasi lain (chooser sistem) ----------

fun Context.openExternal(f: File) {
    val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase())
        ?: if (kindOf(f.name) == Kind.TEXT) "text/plain" else "*/*"
    try {
        val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(view, "Buka dengan").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(this, "Tidak ada aplikasi untuk membuka file ini", Toast.LENGTH_LONG).show()
    }
}

// ---------- Salin ke lokasi sementara supaya file dari arsip / SAF / Shizuku bisa dibuka ----------

private fun tmpDir(ctx: Context, external: Boolean): File {
    val base = if (external) File(workDir(), ".tmp") else File(ctx.cacheDir, "open")
    base.mkdirs()
    val now = System.currentTimeMillis()
    base.listFiles()?.forEach { if (now - it.lastModified() > 12 * 3600_000L) it.deleteRecursively() }
    return File(base, now.toString()).also { it.mkdirs() }
}

fun materialize(ctx: Context, loc: Loc, n: Node, pass: String): File = when (loc) {
    is Loc.Disk -> File(n.id)
    is Loc.Arc -> {
        val d = tmpDir(ctx, false)
        FileOps.extractFrom(loc.file, pass, setOf(n.id), loc.inner, d)
        File(d, n.name)
    }
    is Loc.Saf -> {
        val d = tmpDir(ctx, false)
        Saf.copyOut(ctx.contentResolver, loc.tree, n, d)
        File(d, n.name)
    }
    is Loc.Sh -> {
        val d = tmpDir(ctx, true)
        Shell.cp(n.id, d.path)
        File(d, n.name)
    }
}

// ---------- Buat / ganti nama ----------

fun createFolder(ctx: Context, loc: Loc, name: String) {
    when (loc) {
        is Loc.Disk -> {
            val f = File(loc.dir, name)
            check(!f.exists()) { "Sudah ada" }
            check(f.mkdirs()) { "Gagal membuat folder" }
        }
        is Loc.Sh -> Shell.mkdirNew(loc.path.trimEnd('/') + "/" + name)
        is Loc.Saf -> Saf.mkdir(ctx.contentResolver, loc.tree, loc.docId, name)
        is Loc.Arc -> throw IllegalStateException("Tidak bisa membuat folder di dalam arsip")
    }
}

// Mengembalikan File kalau dibuat di penyimpanan biasa (supaya bisa langsung dibuka di editor)
fun createFile(ctx: Context, loc: Loc, name: String): File? = when (loc) {
    is Loc.Disk -> {
        val f = File(loc.dir, name)
        check(!f.exists()) { "Sudah ada" }
        check(f.createNewFile()) { "Gagal membuat file" }
        f
    }
    is Loc.Sh -> { Shell.touch(loc.path.trimEnd('/') + "/" + name); null }
    is Loc.Saf -> { Saf.createFile(ctx.contentResolver, loc.tree, loc.docId, name); null }
    is Loc.Arc -> throw IllegalStateException("Tidak bisa membuat file di dalam arsip")
}

fun renameNode(ctx: Context, loc: Loc, n: Node, newName: String) {
    when (loc) {
        is Loc.Disk -> {
            val f = File(n.id)
            val t = File(f.parentFile, newName)
            if (!newName.equals(n.name, ignoreCase = true)) check(!t.exists()) { "Sudah ada" }
            check(f.renameTo(t)) { "Gagal mengganti nama" }
        }
        is Loc.Sh -> Shell.rename(n.id, newName)
        is Loc.Saf -> Saf.rename(ctx.contentResolver, loc.tree, n, newName)
        is Loc.Arc -> {
            check(FileOps.isZipLike(loc.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            val parent = n.id.substringBeforeLast('/', "")
            val to = if (parent.isEmpty()) newName else "$parent/$newName"
            FileOps.editZip(loc.file, emptySet(), emptyMap(), ctx.filesDir, n.id to to)
        }
    }
}

// ---------- Teks: baca / simpan ----------

private fun loadText(f: File): Triple<String, Charset, Boolean> {
    if (f.length() > MAX_TEXT) error("File terlalu besar untuk editor (${sizeText(f.length())}). Buka dengan aplikasi lain.")
    val b = f.readBytes()
    for (i in 0 until minOf(b.size, 8000)) if (b[i] == 0.toByte()) error("Sepertinya bukan file teks (berisi data biner).")
    val (s, cs) = try {
        Charsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT).onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(b)).toString() to Charsets.UTF_8
    } catch (e: CharacterCodingException) {
        String(b, Charsets.ISO_8859_1) to Charsets.ISO_8859_1
    }
    val crlf = s.contains("\r\n")
    return Triple(if (crlf) s.replace("\r\n", "\n") else s, cs, crlf)
}

fun saveText(ctx: Context, s: TextSrc, bytes: ByteArray) {
    s.file.writeBytes(bytes)
    when (val o = s.origin) {
        is Loc.Disk -> {}
        is Loc.Sh -> Shell.put(s.file.path, s.node.id)
        is Loc.Saf -> {
            val out = ctx.contentResolver.openOutputStream(Saf.docUri(o.tree, s.node.id), "wt")
                ?: error("Tidak bisa menulis ${s.node.name}")
            out.use { it.write(bytes) }
        }
        is Loc.Arc -> {
            check(FileOps.isZipLike(o.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            FileOps.editZip(o.file, emptySet(), mapOf(s.node.id to s.file), ctx.filesDir)
        }
    }
}

// ---------- Dialog nama (folder baru, file baru, ganti nama) ----------

@Composable
fun NameDialog(
    title: String, label: String, initial: String, ok: String,
    onDismiss: () -> Unit, onOk: (String) -> Unit
) {
    val base = if (initial.contains('.') && !initial.startsWith(".")) initial.substringBeforeLast('.') else initial
    var v by remember { mutableStateOf(TextFieldValue(initial, TextRange(0, base.length))) }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { delay(150); runCatching { fr.requestFocus() } }
    val t = v.text.trim()
    val bad = t.isEmpty() || t.contains('/') || t == "." || t == ".."
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            OutlinedTextField(
                v, { v = it }, label = { Text(label) }, singleLine = true,
                isError = t.contains('/'), modifier = Modifier.focusRequester(fr)
            )
        },
        confirmButton = { TextButton(onClick = { onOk(t) }, enabled = !bad) { Text(ok) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

// ---------- Editor teks ----------

@Composable
fun TextScreen(src: TextSrc, onBack: () -> Unit, onExternal: () -> Unit, onPreview: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val o = src.origin
    val readOnly = o is Loc.Arc && !FileOps.isZipLike(o.file)
    val isHtml = kindOf(src.node.name) == Kind.HTML
    var text by remember(src) { mutableStateOf<String?>(null) }
    var orig by remember(src) { mutableStateOf("") }
    var charset by remember(src) { mutableStateOf<Charset>(Charsets.UTF_8) }
    var crlf by remember(src) { mutableStateOf(false) }
    var err by remember(src) { mutableStateOf<String?>(null) }
    var wrap by remember { mutableStateOf(true) }
    var menu by remember { mutableStateOf(false) }
    var askLeave by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val modified = text != null && text != orig

    LaunchedEffect(src) {
        val r = withContext(Dispatchers.IO) { runCatching { loadText(src.file) } }
        r.onSuccess { (t, c, cr) -> text = t; orig = t; charset = c; crlf = cr }
        r.onFailure { err = it.message ?: "Gagal membuka file" }
    }

    fun save(next: () -> Unit) {
        val t = text ?: return
        scope.launch {
            saving = true
            val body = if (crlf) t.replace("\n", "\r\n") else t
            val r = withContext(Dispatchers.IO) { runCatching { saveText(ctx, src, body.toByteArray(charset)) } }
            saving = false
            r.onSuccess { orig = t; next() }
            r.onFailure { snack.showSnackbar("Gagal menyimpan: ${it.message}") }
        }
    }

    fun leave() { if (modified) askLeave = true else onBack() }

    BackHandler { leave() }

    Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            CompactBar(
                (if (modified) "● " else "") + src.node.name,
                { IconButton({ leave() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } }
            ) {
                if (modified && !readOnly) {
                    IconButton({ save { scope.launch { snack.showSnackbar("Tersimpan") } } }) { Icon(Icons.Rounded.Save, null) }
                }
                IconButton({ wrap = !wrap }) {
                    Icon(Icons.Rounded.WrapText, null, tint = if (wrap) cs.primary else cs.onSurfaceVariant)
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(menu, { menu = false }) {
                        if (isHtml) MI(Icons.Rounded.Language, "Pratinjau HTML") {
                            menu = false
                            if (modified && !readOnly) save { onPreview() } else onPreview()
                        }
                        MI(Icons.Rounded.FileOpen, "Buka dengan…") { menu = false; onExternal() }
                    }
                }
            }
        }
    ) { pad ->
        val t = text
        val e = err
        when {
            e != null -> Column(Modifier.padding(pad).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(e, fontSize = 14.sp)
                Button(onClick = onExternal) { Text("Buka dengan aplikasi lain") }
            }
            t == null -> Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            else -> Column(Modifier.padding(pad).fillMaxSize()) {
                Box(Modifier.fillMaxWidth().height(3.dp)) { if (saving) LinearProgressIndicator(Modifier.fillMaxWidth()) }
                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val minW = maxWidth
                    val minH = maxHeight
                    val vs = rememberScrollState()
                    val hs = rememberScrollState()
                    Box(
                        Modifier.fillMaxSize().verticalScroll(vs)
                            .then(if (wrap) Modifier else Modifier.horizontalScroll(hs))
                    ) {
                        BasicTextField(
                            value = t,
                            onValueChange = { if (!readOnly) text = it },
                            readOnly = readOnly,
                            textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, lineHeight = 18.sp, color = cs.onSurface),
                            cursorBrush = SolidColor(cs.primary),
                            modifier = (if (wrap) Modifier.fillMaxWidth() else Modifier.widthIn(min = minW))
                                .heightIn(min = minH).padding(12.dp)
                        )
                    }
                }
            }
        }
    }

    if (askLeave) {
        AlertDialog(
            onDismissRequest = { askLeave = false },
            title = { Text("Simpan perubahan?") },
            text = { Text(src.node.name) },
            confirmButton = { TextButton(onClick = { askLeave = false; save { onBack() } }) { Text("Simpan") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { askLeave = false }) { Text("Batal") }
                    TextButton(onClick = { askLeave = false; onBack() }) { Text("Buang") }
                }
            }
        )
    }
}

// ---------- Penampil gambar ----------

private fun decodeImage(f: File, max: Int = 2560): ImageBitmap {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(f.path, bounds)
    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("Bukan gambar yang didukung")
    var s = 1
    while (bounds.outWidth / s > max || bounds.outHeight / s > max) s *= 2
    var b: Bitmap = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = s })
        ?: error("Gagal membaca gambar")
    val rot = runCatching {
        when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
        }
    }.getOrDefault(0f)
    if (rot != 0f) b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(rot) }, true)
    return b.asImageBitmap()
}

@Composable
fun ImageScreen(file: File, onBack: () -> Unit, onExternal: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    var bmp by remember(file) { mutableStateOf<ImageBitmap?>(null) }
    var err by remember(file) { mutableStateOf<String?>(null) }
    var scale by remember(file) { mutableFloatStateOf(1f) }
    var off by remember(file) { mutableStateOf(Offset.Zero) }

    LaunchedEffect(file) {
        val r = withContext(Dispatchers.IO) { runCatching { decodeImage(file) } }
        r.onSuccess { bmp = it }
        r.onFailure { err = it.message ?: "Gagal membuka gambar" }
    }
    BackHandler(onBack = onBack)

    Column(Modifier.fillMaxSize().background(cs.background)) {
        CompactBar(file.name, { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } }) {
            IconButton(onExternal) { Icon(Icons.Rounded.FileOpen, null) }
        }
        Box(
            Modifier.weight(1f).fillMaxWidth().background(Color.Black).clipToBounds()
                .pointerInput(file) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        val ns = (scale * zoom).coerceIn(1f, 8f)
                        val mx = size.width * (ns - 1f) / 2f
                        val my = size.height * (ns - 1f) / 2f
                        off = if (ns == 1f) Offset.Zero
                        else Offset((off.x + pan.x).coerceIn(-mx, mx), (off.y + pan.y).coerceIn(-my, my))
                        scale = ns
                    }
                }
                .pointerInput(file) {
                    detectTapGestures(onDoubleTap = {
                        if (scale > 1f) { scale = 1f; off = Offset.Zero } else scale = 2.5f
                    })
                },
            contentAlignment = Alignment.Center
        ) {
            val b = bmp
            val e = err
            when {
                b != null -> Image(
                    b, null,
                    Modifier.fillMaxSize().graphicsLayer(scaleX = scale, scaleY = scale, translationX = off.x, translationY = off.y),
                    contentScale = ContentScale.Fit
                )
                e != null -> Text(e, color = Color.White, modifier = Modifier.padding(20.dp))
                else -> CircularProgressIndicator()
            }
        }
    }
}

// ---------- Pratinjau HTML (dijalankan di dalam aplikasi) ----------

@Composable
fun WebScreen(file: File, onBack: () -> Unit, onExternal: () -> Unit) {
    var wv by remember { mutableStateOf<WebView?>(null) }
    var title by remember(file) { mutableStateOf(file.name) }

    BackHandler {
        val w = wv
        if (w != null && w.canGoBack()) w.goBack() else onBack()
    }
    DisposableEffect(Unit) { onDispose { wv?.destroy() } }

    Column(Modifier.fillMaxSize()) {
        CompactBar(title, { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } }) {
            IconButton({ wv?.reload() }) { Icon(Icons.Rounded.Refresh, null) }
            IconButton(onExternal) { Icon(Icons.Rounded.OpenInBrowser, null) }
        }
        AndroidView(
            factory = { c ->
                WebView(c).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.allowFileAccess = true
                    settings.allowContentAccess = true
                    settings.builtInZoomControls = true
                    settings.displayZoomControls = false
                    settings.useWideViewPort = true
                    settings.loadWithOverviewMode = true
                    webViewClient = WebViewClient()
                    webChromeClient = object : WebChromeClient() {
                        override fun onReceivedTitle(view: WebView?, t: String?) {
                            if (!t.isNullOrBlank()) title = t
                        }
                    }
                    loadUrl(Uri.fromFile(file).toString())
                    wv = this
                }
            },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )
    }
}
