package com.arsipku;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Mengubah nama paket (dan label) pada AndroidManifest.xml biner (AXML). */
public final class AxmlPatcher {
    private AxmlPatcher() {}

    private static final Set<String> COMP = new HashSet<>(Arrays.asList(
            "application", "activity", "activity-alias", "service", "receiver", "provider", "instrumentation"));
    private static final Set<String> PERM = new HashSet<>(Arrays.asList(
            "permission", "permission-group", "permission-tree", "uses-permission", "uses-permission-sdk-23"));
    private static final Set<String> CLS_ATTR = new HashSet<>(Arrays.asList(
            "parentActivityName", "targetActivity", "backupAgent", "manageSpaceActivity"));

    private static final class Pool {
        List<String> s = new ArrayList<>();
        boolean utf8;
        int flags;
        int end;
    }

    private static int u16(byte[] b, int o) { return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8); }
    private static int i32(byte[] b, int o) {
        return (b[o] & 0xFF) | ((b[o + 1] & 0xFF) << 8) | ((b[o + 2] & 0xFF) << 16) | ((b[o + 3] & 0xFF) << 24);
    }
    private static void put32(byte[] b, int o, int v) {
        b[o] = (byte) v; b[o + 1] = (byte) (v >> 8); b[o + 2] = (byte) (v >> 16); b[o + 3] = (byte) (v >> 24);
    }

    private static Pool readPool(byte[] b, int off) {
        if (u16(b, off) != 0x0001) throw new IllegalStateException("Bukan AXML (string pool tidak ditemukan)");
        int hdr = u16(b, off + 2), size = i32(b, off + 4);
        int count = i32(b, off + 8), styles = i32(b, off + 12), flags = i32(b, off + 16), start = i32(b, off + 20);
        if (styles != 0) throw new IllegalStateException("Manifest dengan style belum didukung");
        Pool p = new Pool();
        p.flags = flags; p.utf8 = (flags & 0x100) != 0; p.end = off + size;
        for (int i = 0; i < count; i++) {
            int q = off + start + i32(b, off + hdr + 4 * i);
            if (p.utf8) {
                int cl = b[q++] & 0xFF;
                if ((cl & 0x80) != 0) cl = ((cl & 0x7F) << 8) | (b[q++] & 0xFF);
                int bl = b[q++] & 0xFF;
                if ((bl & 0x80) != 0) bl = ((bl & 0x7F) << 8) | (b[q++] & 0xFF);
                p.s.add(new String(b, q, bl, StandardCharsets.UTF_8));
            } else {
                int cl = u16(b, q); q += 2;
                if ((cl & 0x8000) != 0) { cl = ((cl & 0x7FFF) << 16) | u16(b, q); q += 2; }
                p.s.add(new String(b, q, cl * 2, StandardCharsets.UTF_16LE));
            }
        }
        return p;
    }

    private static void len8(ByteArrayOutputStream o, int n) {
        if (n > 0x7F) { o.write((n >> 8) | 0x80); o.write(n & 0xFF); } else o.write(n);
    }

    private static byte[] writePool(Pool p) {
        ByteArrayOutputStream d = new ByteArrayOutputStream();
        int n = p.s.size();
        int[] offs = new int[n];
        for (int i = 0; i < n; i++) {
            offs[i] = d.size();
            String s = p.s.get(i);
            if (p.utf8) {
                byte[] u = s.getBytes(StandardCharsets.UTF_8);
                len8(d, s.length()); len8(d, u.length);
                d.write(u, 0, u.length); d.write(0);
            } else {
                int cl = s.length();
                if (cl > 0x7FFF) {
                    int hi = (cl >> 16) | 0x8000;
                    d.write(hi & 0xFF); d.write(hi >> 8);
                    d.write(cl & 0xFF); d.write((cl >> 8) & 0xFF);
                } else { d.write(cl & 0xFF); d.write(cl >> 8); }
                byte[] u = s.getBytes(StandardCharsets.UTF_16LE);
                d.write(u, 0, u.length); d.write(0); d.write(0);
            }
        }
        while (d.size() % 4 != 0) d.write(0);
        int strStart = 28 + 4 * n;
        int size = strStart + d.size();
        ByteBuffer bb = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN);
        bb.putShort((short) 0x0001).putShort((short) 28).putInt(size).putInt(n).putInt(0)
                .putInt(p.flags & ~1).putInt(strStart).putInt(0);
        for (int o : offs) bb.putInt(o);
        bb.put(d.toByteArray());
        return bb.array();
    }

    private interface Attr { void on(String el, String name, int a, String value); }

    private static void scan(byte[] b, Pool p, Attr cb) {
        int pos = p.end;
        while (pos + 8 <= b.length) {
            int type = u16(b, pos), size = i32(b, pos + 4);
            if (size <= 0) break;
            if (type == 0x0102) {
                int ext = pos + 16;
                String el = p.s.get(i32(b, ext + 4));
                cb.on(el, null, -1, null);
                int as = u16(b, ext + 8), asz = u16(b, ext + 10), cnt = u16(b, ext + 12);
                for (int i = 0; i < cnt; i++) {
                    int a = ext + as + i * asz;
                    int nameIdx = i32(b, a + 4);
                    if (nameIdx < 0 || nameIdx >= p.s.size()) continue;
                    int dtype = b[a + 15] & 0xFF;
                    String v = null;
                    if (dtype == 3) { int di = i32(b, a + 16); if (di >= 0 && di < p.s.size()) v = p.s.get(di); }
                    cb.on(el, p.s.get(nameIdx), a, v);
                }
            }
            pos += size;
        }
    }

    public static String packageOf(byte[] b) {
        Pool p = readPool(b, 8);
        final String[] r = new String[1];
        scan(b, p, (el, n, a, v) -> { if (r[0] == null && n != null && "manifest".equals(el) && "package".equals(n)) r[0] = v; });
        return r[0];
    }

    private static boolean under(String v, String old) {
        return v.equals(old) || v.startsWith(old + ".") || v.startsWith(old + ":");
    }
    private static String swap(String v, String old, String nw) {
        return under(v, old) ? nw + v.substring(old.length()) : v;
    }
    private static String expand(String v, String old) {
        if (v.startsWith(".")) return old + v;
        if (v.indexOf('.') < 0) return old + "." + v;
        return v;
    }

    public static byte[] patch(byte[] src, final String newPkg, final String newLabel) {
        final byte[] b = src.clone();
        final Pool p = readPool(b, 8);
        final String old = packageOf(b);
        if (old == null) throw new IllegalStateException("Atribut package tidak ditemukan");
        final Map<String, Integer> added = new HashMap<>();
        final int[] launcherLabel = {-1};
        final int[] changed = {0};

        class Setter {
            void set(int a, String s) {
                Integer i = added.get(s);
                if (i == null) { p.s.add(s); i = p.s.size() - 1; added.put(s, i); }
                put32(b, a + 8, i); b[a + 15] = 3; put32(b, a + 16, i);
                changed[0]++;
            }
        }
        final Setter st = new Setter();

        scan(b, p, (el, an, a, v) -> {
            if (an == null) {
                if ("activity".equals(el) || "activity-alias".equals(el) || "service".equals(el)
                        || "receiver".equals(el) || "provider".equals(el)) launcherLabel[0] = -1;
                return;
            }
            if ("manifest".equals(el) && "package".equals(an)) { st.set(a, newPkg); return; }
            if ("manifest".equals(el) && "sharedUserId".equals(an) && v != null) { st.set(a, newPkg + ".shared"); return; }
            if (newLabel != null && "label".equals(an)) {
                if ("application".equals(el)) st.set(a, newLabel);
                if ("activity".equals(el) || "activity-alias".equals(el)) launcherLabel[0] = a;
            }
            if (newLabel != null && "category".equals(el) && "name".equals(an)
                    && "android.intent.category.LAUNCHER".equals(v) && launcherLabel[0] >= 0) {
                st.set(launcherLabel[0], newLabel);
            }
            if (v == null) return;
            String nv = null;
            if ("name".equals(an) && COMP.contains(el)) nv = expand(v, old);
            else if (COMP.contains(el) && CLS_ATTR.contains(an)) nv = expand(v, old);
            else if ("name".equals(an) && PERM.contains(el)) nv = swap(v, old, newPkg);
            else if ("permission".equals(an) || "readPermission".equals(an) || "writePermission".equals(an)
                    || "process".equals(an) || "taskAffinity".equals(an)) nv = swap(v, old, newPkg);
            else if ("authorities".equals(an)) {
                StringBuilder sb = new StringBuilder();
                for (String x : v.split(";")) {
                    String y = swap(x, old, newPkg);
                    if (y.equals(x)) y = newPkg + "." + x;
                    if (sb.length() > 0) sb.append(';');
                    sb.append(y);
                }
                nv = sb.toString();
            } else if ("targetPackage".equals(an) && v.equals(old)) nv = newPkg;
            if (nv != null && !nv.equals(v)) st.set(a, nv);
        });

        byte[] pool = writePool(p);
        byte[] out = new byte[8 + pool.length + (b.length - p.end)];
        System.arraycopy(b, 0, out, 0, 8);
        System.arraycopy(pool, 0, out, 8, pool.length);
        System.arraycopy(b, p.end, out, 8 + pool.length, b.length - p.end);
        put32(out, 4, out.length);
        return out;
    }
}
