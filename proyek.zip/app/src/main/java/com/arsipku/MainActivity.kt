package com.arsipku

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)
    private var mode by mutableIntStateOf(2)
    private var tick by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = getSharedPreferences("p", 0).getInt("theme", 2)
        setContent {
            AppTheme(mode) {
                if (granted) FileManager(mode, tick) {
                    mode = (mode + 1) % 3
                    getSharedPreferences("p", 0).edit().putInt("theme", mode).apply()
                } else PermScreen { ask() }
            }
        }
    }

    override fun onResume() { super.onResume(); granted = hasAccess(); tick++ }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun ask() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }
}

fun Context.installApk(f: File) {
    if (!packageManager.canRequestPackageInstalls()) {
        startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
    startActivity(
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private val Dark = darkColorScheme(
    primary = Color(0xFF6FE3B0), onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF0F5A44), onPrimaryContainer = Color(0xFFA6F5CF),
    secondary = Color(0xFF9FC4FF), onSecondary = Color(0xFF00315F),
    secondaryContainer = Color(0xFF1E4A7E), onSecondaryContainer = Color(0xFFD3E4FF),
    tertiary = Color(0xFFFFB870), onTertiary = Color(0xFF492900),
    tertiaryContainer = Color(0xFF6A3C00), onTertiaryContainer = Color(0xFFFFDCBB),
    background = Color(0xFF10131A), onBackground = Color(0xFFE3E4EC),
    surface = Color(0xFF10131A), onSurface = Color(0xFFE3E4EC),
    surfaceVariant = Color(0xFF2A2F3A), onSurfaceVariant = Color(0xFFC2C6D2),
    surfaceContainer = Color(0xFF181C25), surfaceContainerHigh = Color(0xFF1F2430),
    surfaceContainerHighest = Color(0xFF272C37), outline = Color(0xFF8C909C)
)

private val Light = lightColorScheme(
    primary = Color(0xFF006C4F), onPrimary = Color.White,
    primaryContainer = Color(0xFFA6F5CF), onPrimaryContainer = Color(0xFF002116),
    secondary = Color(0xFF2F5FA8), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3E4FF), onSecondaryContainer = Color(0xFF001B3E),
    tertiary = Color(0xFF8B5000), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDCBB), onTertiaryContainer = Color(0xFF2C1600),
    background = Color(0xFFF5F8F6), onBackground = Color(0xFF191C1B),
    surface = Color(0xFFF5F8F6), onSurface = Color(0xFF191C1B),
    surfaceVariant = Color(0xFFDDE5DF), onSurfaceVariant = Color(0xFF414943),
    surfaceContainer = Color(0xFFEBF0EC), surfaceContainerHigh = Color(0xFFE4EAE6),
    surfaceContainerHighest = Color(0xFFDDE4DF), outline = Color(0xFF717973)
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    // Material You: warna mengikuti wallpaper (Android 12+); di bawah itu pakai palet bawaan
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> Dark
        else -> Light
    }
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = cs.surfaceContainer.toArgb()
        w.navigationBarColor = cs.background.toArgb()
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = cs,
        shapes = Shapes(
            small = RoundedCornerShape(8.dp), medium = RoundedCornerShape(12.dp),
            large = RoundedCornerShape(16.dp), extraLarge = RoundedCornerShape(24.dp)
        ),
        content = content
    )
}

@Composable
fun PermScreen(onAsk: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Archive, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Arsipku butuh akses ke semua file", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("Untuk menjelajah, memindahkan, dan mengekstrak file.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAsk) { Text("Beri izin") }
        }
    }
}

sealed class Dlg {
    object NewFolder : Dlg()
    object Delete : Dlg()
    object Compress : Dlg()
    object ShizukuInfo : Dlg()
    object Pass : Dlg()
    class Open(val f: File) : Dlg()
    class Apk(val f: File) : Dlg()
    class Sign(val f: File) : Dlg()
}

class Clip(val from: Loc, val nodes: List<Node>, val cut: Boolean)

class AppItem(
    val label: String, val pkg: String, val apk: File, val splitDirs: List<String>,
    val version: String, val system: Boolean, val icon: ImageBitmap?
)

private val df: DateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM)

fun sizeText(b: Long): String {
    if (b < 1024) return "$b B"
    val u = listOf("KB", "MB", "GB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 2) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

fun workDir(): File =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Arsipku").also { it.mkdirs() }

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0).map { ai ->
        val ver = runCatching { pm.getPackageInfo(ai.packageName, 0).versionName }.getOrNull() ?: ""
        AppItem(
            pm.getApplicationLabel(ai).toString(), ai.packageName, File(ai.sourceDir),
            ai.splitSourceDirs?.toList() ?: emptyList(), ver, (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
            runCatching { ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        )
    }.sortedBy { it.label.lowercase() }
}

fun parentOf(loc: Loc, root: File, safRoot: String?): Loc? = when (loc) {
    is Loc.Disk -> if (loc.dir == root) null else Loc.Disk(loc.dir.parentFile ?: root)
    is Loc.Arc -> if (loc.inner.isEmpty()) Loc.Disk(loc.file.parentFile ?: root) else {
        val up = loc.inner.trimEnd('/').substringBeforeLast('/', "")
        Loc.Arc(loc.file, if (up.isEmpty()) "" else "$up/")
    }
    is Loc.Saf -> if (loc.docId == safRoot || !loc.docId.contains('/')) Loc.Disk(root)
        else Loc.Saf(loc.tree, loc.docId.substringBeforeLast('/'))
    is Loc.Sh -> {
        val base = root.path + "/Android"
        val cur = loc.path.trimEnd('/')
        when {
            cur == base || !cur.startsWith(base) -> Loc.Disk(root)
            cur.substringBeforeLast('/') == base -> Loc.Disk(File(base))
            else -> Loc.Sh(cur.substringBeforeLast('/'))
        }
    }
}

fun loadNodes(ctx: Context, loc: Loc, cache: MutableMap<String, List<Entry>>, pass: String): List<Node> = when (loc) {
    is Loc.Disk -> (loc.dir.listFiles() ?: emptyArray()).map {
        Node(it.name, it.isDirectory, if (it.isDirectory) 0L else it.length(), it.lastModified(), it.path)
    }.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    is Loc.Arc -> FileOps.children(cache.getOrPut(loc.file.path) { FileOps.list(loc.file, pass) }, loc.inner)
    is Loc.Saf -> Saf.list(ctx.contentResolver, loc.tree, loc.docId)
    is Loc.Sh -> Shell.list(loc.path)
}

fun deleteNodes(ctx: Context, loc: Loc, nodes: List<Node>) {
    when (loc) {
        is Loc.Disk -> nodes.forEach { File(it.id).deleteRecursively() }
        is Loc.Arc -> {
            check(FileOps.isZipLike(loc.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            FileOps.editZip(loc.file, nodes.map { it.id }.toSet(), emptyMap(), ctx.filesDir)
        }
        is Loc.Saf -> nodes.forEach { Saf.delete(ctx.contentResolver, loc.tree, it) }
        is Loc.Sh -> nodes.forEach { Shell.rm(it.id) }
    }
}

fun transfer(ctx: Context, clip: Clip, dest: Loc, pass: String) {
    val from = clip.from
    val cr = ctx.contentResolver
    when {
        from is Loc.Disk && dest is Loc.Disk ->
            clip.nodes.forEach { val f = File(it.id); if (clip.cut) FileOps.move(f, dest.dir) else FileOps.copy(f, dest.dir) }
        from is Loc.Arc && dest is Loc.Disk -> {
            FileOps.extractFrom(from.file, pass, clip.nodes.map { it.id }.toSet(), from.inner, dest.dir)
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Saf && dest is Loc.Disk -> {
            clip.nodes.forEach { Saf.copyOut(cr, from.tree, it, dest.dir) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Disk && dest is Loc.Arc -> {
            check(FileOps.isZipLike(dest.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            val adds = FileOps.collectAdds(clip.nodes.map { File(it.id) }, dest.inner)
            FileOps.editZip(dest.file, emptySet(), adds, ctx.filesDir)
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Disk && dest is Loc.Saf -> {
            clip.nodes.forEach { Saf.copyIn(cr, dest.tree, dest.docId, File(it.id)) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Sh && dest is Loc.Disk -> {
            clip.nodes.forEach { Shell.cp(it.id, dest.dir.path) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Disk && dest is Loc.Sh -> {
            clip.nodes.forEach { Shell.cp(it.id, dest.path) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Sh && dest is Loc.Sh ->
            clip.nodes.forEach { if (clip.cut) Shell.mv(it.id, dest.path) else Shell.cp(it.id, dest.path) }
        else -> throw IllegalStateException("Kombinasi sumber dan tujuan ini belum didukung")
    }
}

@Composable
fun Tile(name: String, dir: Boolean, on: Boolean = false) {
    val c = MaterialTheme.colorScheme
    val (icon, bg, fg) = when {
        on -> Triple(Icons.Rounded.Check, c.primary, c.onPrimary)
        dir -> Triple(Icons.Rounded.Folder, c.tertiaryContainer, c.onTertiaryContainer)
        name.endsWith(".apk", true) -> Triple(Icons.Rounded.Android, c.primaryContainer, c.onPrimaryContainer)
        FileOps.isArcName(name) -> Triple(Icons.Rounded.Archive, c.secondaryContainer, c.onSecondaryContainer)
        else -> Triple(Icons.Rounded.Description, c.surfaceVariant, c.onSurfaceVariant)
    }
    Box(Modifier.size(36.dp).background(bg, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
        Icon(icon, null, Modifier.size(20.dp), tint = fg)
    }
}

@Composable
fun Act(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, Modifier.size(22.dp))
        Text(label, fontSize = 10.sp, maxLines = 1)
    }
}

@Composable
fun MenuBtn(icon: ImageVector, text: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Text(text, fontSize = 14.sp)
    }
}

@Composable
fun MI(icon: ImageVector, text: String, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text, fontSize = 14.sp) },
        leadingIcon = { Icon(icon, null, Modifier.size(20.dp)) },
        onClick = onClick
    )
}

@Composable
fun CompactBar(title: String, nav: (@Composable () -> Unit)? = null, actions: @Composable RowScope.() -> Unit = {}) {
    val cs = MaterialTheme.colorScheme
    Surface(color = cs.surfaceContainer) {
        Row(
            Modifier
                .windowInsetsPadding(WindowInsets.systemBars.only(WindowInsetsSides.Top + WindowInsetsSides.Horizontal))
                .fillMaxWidth().height(48.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (nav != null) nav() else Spacer(Modifier.width(12.dp))
            Text(
                title, Modifier.weight(1f).padding(horizontal = 4.dp),
                fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            actions()
        }
    }
}

class Crumb(val label: String, val to: Loc?)

fun crumbsOf(loc: Loc, root: File, safRoot: String?): List<Crumb> {
    val out = ArrayList<Crumb>()
    when (loc) {
        is Loc.Disk -> {
            out.add(Crumb("Penyimpanan", Loc.Disk(root)))
            var cur = root
            loc.dir.path.removePrefix(root.path).split('/').filter { it.isNotEmpty() }.forEach { p ->
                cur = File(cur, p)
                out.add(Crumb(p, Loc.Disk(cur)))
            }
        }
        is Loc.Arc -> {
            out.add(Crumb(loc.file.name, Loc.Arc(loc.file, "")))
            var acc = ""
            loc.inner.split('/').filter { it.isNotEmpty() }.forEach { p ->
                acc += "$p/"
                out.add(Crumb(p, Loc.Arc(loc.file, acc)))
            }
        }
        is Loc.Sh -> {
            out.add(Crumb("Penyimpanan", Loc.Disk(root)))
            var cur = root.path
            loc.path.removePrefix(root.path).split('/').filter { it.isNotEmpty() }.forEachIndexed { i, p ->
                cur += "/$p"
                out.add(Crumb(p, if (i == 0) Loc.Disk(File(cur)) else Loc.Sh(cur)))
            }
        }
        is Loc.Saf -> {
            out.add(Crumb("Penyimpanan", Loc.Disk(root)))
            var path = ""
            loc.docId.removePrefix("primary:").split('/').filter { it.isNotEmpty() }.forEachIndexed { i, p ->
                path += (if (i == 0) "" else "/") + p
                val id = "primary:$path"
                val to: Loc? = when {
                    i == 0 -> Loc.Disk(File(root, p))
                    safRoot != null && id.startsWith(safRoot) -> Loc.Saf(loc.tree, id)
                    else -> null
                }
                out.add(Crumb(p, to))
            }
        }
    }
    return out
}

@Composable
fun Crumbs(list: List<Crumb>, key: Any, onGo: (Loc) -> Unit) {
    val cs = MaterialTheme.colorScheme
    val sc = rememberScrollState()
    LaunchedEffect(key) { snapshotFlow { sc.maxValue }.collect { sc.scrollTo(it) } }
    Row(
        Modifier.fillMaxWidth().horizontalScroll(sc).padding(horizontal = 8.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        list.forEachIndexed { i, c ->
            val last = i == list.lastIndex
            val to = c.to
            if (i > 0) Icon(Icons.Rounded.ChevronRight, null, Modifier.size(16.dp), tint = cs.outline)
            Text(
                c.label,
                Modifier.clip(RoundedCornerShape(8.dp))
                    .then(if (to != null && !last) Modifier.clickable { onGo(to) } else Modifier)
                    .padding(horizontal = 6.dp, vertical = 6.dp),
                fontSize = 13.sp, maxLines = 1,
                color = if (last) cs.primary else cs.onSurfaceVariant,
                fontWeight = if (last) FontWeight.Medium else FontWeight.Normal
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NodeRow(n: Node, on: Boolean, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (on) cs.secondaryContainer else Color.Transparent, label = "bg")
    val info = remember(n) {
        (if (n.isDir) "Folder" else sizeText(n.size)) + (if (n.time > 0) " • " + df.format(Date(n.time)) else "")
    }
    Row(
        modifier.fillMaxWidth().padding(horizontal = 6.dp).clip(RoundedCornerShape(12.dp)).background(bg)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Tile(n.name, n.isDir, on)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(n.name, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(info, fontSize = 11.sp, lineHeight = 14.sp, color = cs.onSurfaceVariant, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var sys by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf<AppItem?>(null) }
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    BackHandler(onBack = onBack)

    var cloneFor by remember { mutableStateOf<AppItem?>(null) }

    fun run(ok: String, job: () -> File, after: (File) -> Unit = {}) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            r.onSuccess {
                if (ok.isNotEmpty()) Toast.makeText(ctx, "$ok: Download/Arsipku/${it.name}", Toast.LENGTH_LONG).show()
                after(it)
            }
            r.onFailure { Toast.makeText(ctx, "Gagal: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    fun safe(a: AppItem) = a.label.replace(Regex("[^A-Za-z0-9 _.-]"), "_")

    fun copyApk(a: AppItem): File {
        val f = File(workDir(), safe(a) + ".apk")
        a.apk.copyTo(f, true)
        return f
    }

    fun extractAll(a: AppItem): File {
        if (a.splitDirs.isEmpty()) return copyApk(a)
        val d = File(workDir(), safe(a))
        d.mkdirs()
        a.apk.copyTo(File(d, "base.apk"), true)
        a.splitDirs.forEach { val s = File(it); s.copyTo(File(d, s.name), true) }
        return d
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            CompactBar(
                "Aplikasi terpasang",
                { IconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } }
            ) {
                FilterChip(selected = sys, onClick = { sys = !sys }, label = { Text("Sistem", fontSize = 12.sp) })
                Spacer(Modifier.width(8.dp))
            }
        }
    ) { pad ->
        val list = apps
        if (list == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(vertical = 4.dp)) {
                items(list.filter { sys || !it.system }, key = { it.pkg }) { a ->
                    Row(
                        Modifier.fillMaxWidth().clickable { pick = a }.padding(horizontal = 14.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (a.icon != null) Image(a.icon, null, Modifier.size(36.dp))
                        else Box(Modifier.size(36.dp))
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(a.label, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                a.pkg + if (a.version.isNotEmpty()) " • " + a.version else "",
                                fontSize = 11.sp, lineHeight = 14.sp, color = cs.onSurfaceVariant,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }
            }
        }
    }

    pick?.let { a ->
        AlertDialog(
            onDismissRequest = { pick = null }, title = { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        a.pkg + (if (a.splitDirs.isNotEmpty()) "\nAplikasi split: ${a.splitDirs.size} APK tambahan." else ""),
                        style = MaterialTheme.typography.bodySmall
                    )
                    MenuBtn(Icons.Rounded.Archive, "Ekstrak APK") { pick = null; run("Tersimpan", { extractAll(a) }) }
                    MenuBtn(Icons.Rounded.FolderOpen, "Bongkar (buka isi APK)") { pick = null; run("", { copyApk(a) }, { onOpen(it) }) }
                    MenuBtn(Icons.Rounded.ContentCopy, "Clone aplikasi") {
                        pick = null
                        if (a.splitDirs.isEmpty()) cloneFor = a
                        else Toast.makeText(ctx, "Aplikasi split belum didukung untuk clone", Toast.LENGTH_LONG).show()
                    }
                    MenuBtn(Icons.Rounded.Edit, "Tanda tangani ulang (paket sama)") {
                        pick = null
                        val fd = ctx.filesDir
                        run("Tersimpan", {
                            val c = copyApk(a)
                            val out = File(c.parentFile, c.name.removeSuffix(".apk") + "-signed.apk")
                            Signer.sign(c, out, Signer.defaultKeystore(fd), Signer.PASS, "", true, true, true)
                            c.delete()
                            out
                        })
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pick = null }) { Text("Batal") } }
        )
    }

    cloneFor?.let { a ->
        var pkg by remember(a) { mutableStateOf(a.pkg + ".clone") }
        var lbl by remember(a) { mutableStateOf(a.label + " 2") }
        AlertDialog(
            onDismissRequest = { cloneFor = null }, title = { Text("Clone ${a.label}", maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(pkg, { pkg = it }, label = { Text("Nama paket baru") }, singleLine = true)
                    OutlinedTextField(lbl, { lbl = it }, label = { Text("Nama aplikasi baru") }, singleLine = true)
                    Text(
                        "Clone memakai tanda tangan Arsipku dan terpasang berdampingan dengan aslinya. " +
                            "Aplikasi yang memeriksa tanda tangan, login Google, atau lisensi bisa tidak berjalan.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val np = pkg.trim(); val nl = lbl.trim(); val fd = ctx.filesDir
                    if (!Regex("[A-Za-z][A-Za-z0-9_]*(\\.[A-Za-z][A-Za-z0-9_]*)+").matches(np) || np == a.pkg) {
                        Toast.makeText(ctx, "Nama paket tidak valid atau sama dengan aslinya", Toast.LENGTH_LONG).show()
                    } else {
                        cloneFor = null
                        run("Clone siap", {
                            val c = copyApk(a)
                            val out = File(c.parentFile, safe(a) + "-clone.apk")
                            try { FileOps.cloneApk(c, out, np, if (nl.isEmpty()) null else nl, fd) } finally { c.delete() }
                            out
                        }, { ctx.installApk(it) })
                    }
                }) { Text("Buat dan pasang") }
            },
            dismissButton = { TextButton(onClick = { cloneFor = null }) { Text("Batal") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManager(themeMode: Int, tick: Int, onTheme: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val root = remember { Environment.getExternalStorageDirectory() }
    var loc by remember { mutableStateOf<Loc>(Loc.Disk(root)) }
    var nodes by remember { mutableStateOf(emptyList<Node>()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var clip by remember { mutableStateOf<Clip?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var arcPass by remember { mutableStateOf("") }
    var shState by remember { mutableStateOf(Shell.state(ctx.packageManager)) }
    var wantPath by remember { mutableStateOf(root.path + "/Android/data") }
    var safTree by remember { mutableStateOf<Uri?>(prefs.getString("saf", null)?.let { Uri.parse(it) }) }
    val cache = remember { HashMap<String, List<Entry>>() }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val cs = MaterialTheme.colorScheme
    val l = loc
    val safRoot = safTree?.let { DocumentsContract.getTreeDocumentId(it) }
    val up = parentOf(l, root, safRoot)
    val selNodes = nodes.filter { it.id in sel }
    val crumbs = remember(l, safRoot) { crumbsOf(l, root, safRoot) }

    fun go(n: Loc) { loc = n; sel = emptySet() }

    fun work(ok: String, job: () -> Unit) {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            busy = false; cache.clear(); reload++; sel = emptySet()
            snack.showSnackbar(r.exceptionOrNull()?.let { "Gagal: ${it.message}" } ?: ok)
        }
    }

    // File di Android/data (lewat Shizuku) disalin dulu ke Download/Arsipku supaya bisa dibuka
    fun openFromShell(n: Node) {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) {
                runCatching { val d = workDir(); Shell.cp(n.id, d.path); File(d, n.name) }
            }
            busy = false
            r.onSuccess { f -> if (f.name.endsWith(".apk", true)) dlg = Dlg.Apk(f) else go(Loc.Arc(f, "")) }
            r.onFailure { snack.showSnackbar("Gagal: ${it.message}") }
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            val id = DocumentsContract.getTreeDocumentId(uri)
            if (id.startsWith("primary:Android/data")) {
                runCatching {
                    ctx.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
                prefs.edit().putString("saf", uri.toString()).apply()
                safTree = uri
                go(Loc.Saf(uri, id))
            } else scope.launch { snack.showSnackbar("Pilih folder Android/data lalu tekan Gunakan folder ini") }
        }
    }

    fun openShizukuPath(path: String) {
        wantPath = path
        val s = Shell.state(ctx.packageManager)
        shState = s
        if (s == ShState.READY) { go(Loc.Sh(path)); return }
        if (s == ShState.NO_PERMISSION && !Shell.rationale()) { Shell.request(1001); return }
        dlg = Dlg.ShizukuInfo
    }

    fun openData() {
        val t = safTree
        if (Build.VERSION.SDK_INT < 33 && !Shell.available()) {
            if (t != null) go(Loc.Saf(t, DocumentsContract.getTreeDocumentId(t))) else picker.launch(Saf.initial)
        } else openShizukuPath(root.path + "/Android/data")
    }

    DisposableEffect(Unit) {
        Shell.listen(ctx) { ok ->
            shState = Shell.state(ctx.packageManager)
            if (ok) { dlg = null; go(Loc.Sh(wantPath)) }
        }
        Shell.watch(ctx) { shState = Shell.state(ctx.packageManager) }
        onDispose { Shell.unlisten(ctx); Shell.unwatch(ctx) }
    }

    LaunchedEffect(tick) { shState = Shell.state(ctx.packageManager) }

    LaunchedEffect(loc, reload) {
        loading = true
        val cur = loc; val pw = arcPass
        val r = withContext(Dispatchers.IO) { runCatching { loadNodes(ctx, cur, cache, pw) } }
        nodes = r.getOrDefault(emptyList())
        loading = false
        r.exceptionOrNull()?.let { snack.showSnackbar("Gagal membuka: ${it.message}") }
    }

    BackHandler(enabled = sel.isNotEmpty() || up != null) {
        if (sel.isNotEmpty()) sel = emptySet() else up?.let { go(it) }
    }

    if (apps) {
        AppsScreen(onBack = { apps = false; reload++ }, onOpen = { f -> apps = false; go(Loc.Arc(f, "")) })
    } else Scaffold(
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            CompactBar(
                title = when {
                    sel.isNotEmpty() -> "${sel.size} dipilih"
                    l is Loc.Arc -> l.file.name
                    l is Loc.Sh -> if (l.path.contains("/Android/obb")) "Android/obb" else "Android/data"
                    l is Loc.Saf -> "Android/data"
                    else -> "Arsipku"
                },
                nav = {
                    if (sel.isNotEmpty()) IconButton({ sel = emptySet() }) { Icon(Icons.Rounded.Close, null) }
                    else if (up != null) IconButton({ go(up) }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                    else Spacer(Modifier.width(48.dp))
                }
            ) {
                if (sel.isNotEmpty()) {
                    IconButton({ sel = nodes.map { it.id }.toSet() }) { Icon(Icons.Rounded.SelectAll, null) }
                } else {
                    IconButton({ openData() }) {
                        BadgedBox(badge = { if (shState == ShState.READY) Badge(containerColor = Color(0xFF34C759)) }) {
                            Icon(Icons.Rounded.FolderSpecial, null)
                        }
                    }
                    IconButton({ apps = true }) { Icon(Icons.Rounded.Apps, null) }
                }
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(menu, { menu = false }) {
                        if (l is Loc.Disk || l is Loc.Sh) MI(Icons.Rounded.CreateNewFolder, "Folder baru") { menu = false; dlg = Dlg.NewFolder }
                        MI(Icons.Rounded.Storage, "Penyimpanan") { menu = false; go(Loc.Disk(root)) }
                        MI(Icons.Rounded.FolderSpecial, "Android/data") { menu = false; openData() }
                        MI(Icons.Rounded.FolderZip, "Android/obb") { menu = false; openShizukuPath(root.path + "/Android/obb") }
                        if (l is Loc.Arc) {
                            MI(Icons.Rounded.Unarchive, "Ekstrak semua") { menu = false; dlg = Dlg.Open(l.file) }
                            MI(Icons.Rounded.Lock, "Password arsip") { menu = false; dlg = Dlg.Pass }
                        }
                        MI(Icons.Rounded.Security, "Status Shizuku") { menu = false; dlg = Dlg.ShizukuInfo }
                        MI(
                            when (themeMode) { 0 -> Icons.Rounded.BrightnessAuto; 1 -> Icons.Rounded.LightMode; else -> Icons.Rounded.DarkMode },
                            when (themeMode) { 0 -> "Tema: otomatis"; 1 -> "Tema: terang"; else -> "Tema: gelap" }
                        ) { menu = false; onTheme() }
                    }
                }
            }
        },
        bottomBar = {
            AnimatedVisibility(
                visible = sel.isNotEmpty() || clip != null,
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) {
                Surface(color = cs.surfaceContainerHigh) {
                    Row(
                        Modifier.windowInsetsPadding(WindowInsets.navigationBars).fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalAlignment = Alignment.CenterVertically
                    ) {
                        val m = Modifier.weight(1f)
                        val c = clip
                        if (sel.isNotEmpty()) {
                            Act(Icons.Rounded.ContentCopy, "Salin", m) { clip = Clip(l, selNodes, false); sel = emptySet() }
                            Act(Icons.Rounded.ContentCut, "Pindah", m) { clip = Clip(l, selNodes, true); sel = emptySet() }
                            if (l is Loc.Disk) Act(Icons.Rounded.Archive, "ZIP", m) { dlg = Dlg.Compress }
                            Act(Icons.Rounded.Delete, "Hapus", m) { dlg = Dlg.Delete }
                        } else if (c != null) {
                            Button(
                                onClick = {
                                    val d = l; val pw = arcPass
                                    clip = null
                                    work("Selesai") { transfer(ctx, c, d, pw) }
                                },
                                modifier = m.height(40.dp)
                            ) { Text("Tempel di sini (${c.nodes.size})", fontSize = 13.sp) }
                            TextButton({ clip = null }) { Text("Batal") }
                        }
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            Crumbs(crumbs, l) { go(it) }
            Box(Modifier.fillMaxWidth().height(3.dp)) {
                if (busy || loading) LinearProgressIndicator(Modifier.fillMaxWidth())
            }
            if (l is Loc.Arc && l.file.name.endsWith(".apk", true)) {
                Text(
                    "Hapus atau tempel file di sini akan otomatis menandatangani ulang APK.",
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp), fontSize = 11.sp, color = cs.onSurfaceVariant
                )
            }
            if (!loading && nodes.isEmpty()) {
                val hint = if (l is Loc.Disk && Build.VERSION.SDK_INT >= 30 && l.dir.path.contains("/Android/data"))
                    "Android/data diblokir untuk akses biasa. Ketuk ikon folder di atas (butuh Shizuku)." else "Kosong"
                Text(hint, Modifier.padding(20.dp), fontSize = 13.sp, color = cs.onSurfaceVariant)
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 4.dp)) {
                items(nodes, key = { it.id }) { n ->
                    NodeRow(
                        n, n.id in sel, Modifier.animateItem(),
                        onClick = {
                            when {
                                sel.isNotEmpty() -> sel = if (n.id in sel) sel - n.id else sel + n.id
                                n.isDir -> when (val c = l) {
                                    is Loc.Disk -> go(Loc.Disk(File(n.id)))
                                    is Loc.Arc -> go(Loc.Arc(c.file, n.id + "/"))
                                    is Loc.Saf -> go(Loc.Saf(c.tree, n.id))
                                    is Loc.Sh -> go(Loc.Sh(n.id))
                                }
                                l is Loc.Disk && n.name.endsWith(".apk", true) -> dlg = Dlg.Apk(File(n.id))
                                l is Loc.Disk && FileOps.isArcName(n.name) -> go(Loc.Arc(File(n.id), ""))
                                l is Loc.Sh && FileOps.isArcName(n.name) -> openFromShell(n)
                                else -> sel = sel + n.id
                            }
                        },
                        onLong = { sel = if (n.id in sel) sel - n.id else sel + n.id }
                    )
                }
            }
        }
    }

    when (val d = dlg) {
        Dlg.NewFolder -> {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Folder baru") },
                text = { OutlinedTextField(name, { name = it }, label = { Text("Nama folder") }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        val n = name.trim(); val t = (l as? Loc.Disk)?.dir; val sp = (l as? Loc.Sh)?.path; dlg = null
                        if (n.isNotEmpty() && t != null) work("Folder dibuat") { File(t, n).mkdirs() }
                        else if (n.isNotEmpty() && sp != null) work("Folder dibuat") { Shell.mkdir("$sp/$n") }
                    }) { Text("Buat") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Hapus ${sel.size} item?") },
            text = { Text("Item yang dihapus tidak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = {
                    val ln = l; val nn = selNodes; dlg = null
                    work("Terhapus") { deleteNodes(ctx, ln, nn) }
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        Dlg.Compress -> {
            var name by remember { mutableStateOf(if (selNodes.size == 1) File(selNodes[0].id).nameWithoutExtension else "arsip") }
            var pass by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Kompres ke ZIP") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text("Nama arsip") }, singleLine = true)
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (opsional)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val files = selNodes.map { File(it.id) }
                        val out = File((l as? Loc.Disk)?.dir ?: root, name.trim().ifEmpty { "arsip" } + ".zip")
                        val p = pass
                        dlg = null; work("Arsip dibuat") { FileOps.zip(files, out, p) }
                    }) { Text("Kompres") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Pass -> {
            var p by remember { mutableStateOf(arcPass) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Password arsip") },
                text = { OutlinedTextField(p, { p = it }, label = { Text("Password") }, singleLine = true) },
                confirmButton = { TextButton(onClick = { arcPass = p; cache.clear(); reload++; dlg = null }) { Text("Simpan") } },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.ShizukuInfo -> {
            val st = shState
            val denied = st == ShState.NO_PERMISSION && Shell.rationale()
            val msg = when (st) {
                ShState.NOT_INSTALLED -> "Shizuku belum terpasang. Pasang Shizuku, jalankan lewat Debugging nirkabel (Android 11+) atau ADB, lalu buka Android/data lagi."
                ShState.NOT_RUNNING -> "Shizuku terpasang tapi belum berjalan. Buka Shizuku lalu ketuk Mulai (Debugging nirkabel, ADB, atau root)."
                ShState.NO_PERMISSION ->
                    if (denied) "Izin untuk Arsipku ditolak permanen. Buka Shizuku, masuk ke daftar aplikasi yang diotorisasi, lalu izinkan Arsipku."
                    else "Shizuku aktif. Arsipku butuh izin Shizuku untuk membuka Android/data."
                ShState.READY -> "Shizuku aktif dan Arsipku sudah diizinkan."
            }
            fun openShizukuApp() {
                val i = ctx.packageManager.getLaunchIntentForPackage(Shell.PKG)
                    ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Shizuku") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(msg, style = MaterialTheme.typography.bodyMedium)
                        if (Build.VERSION.SDK_INT < 33) {
                            MenuBtn(Icons.Rounded.FolderSpecial, "Pakai izin folder (Android 11-12)") { dlg = null; picker.launch(Saf.initial) }
                        }
                    }
                },
                confirmButton = {
                    when {
                        st == ShState.READY -> TextButton(onClick = { dlg = null; go(Loc.Sh(wantPath)) }) { Text("Buka folder") }
                        st == ShState.NO_PERMISSION && !denied -> TextButton(onClick = { Shell.request(1001) }) { Text("Izinkan") }
                        st == ShState.NOT_INSTALLED -> TextButton(onClick = { dlg = null; openShizukuApp() }) { Text("Unduh Shizuku") }
                        else -> TextButton(onClick = { dlg = null; openShizukuApp() }) { Text("Buka Shizuku") }
                    }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Tutup") } }
            )
        }
        is Dlg.Open -> {
            var pass by remember { mutableStateOf(arcPass) }
            var newDir by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (jika ada)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(newDir, { newDir = it })
                            Text("Ekstrak ke folder baru")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f; val p = pass
                        val to = if (newDir) File(a.parentFile, a.name.substringBefore(".")) else a.parentFile!!
                        dlg = null; work("Selesai diekstrak") { FileOps.extract(a, to, p) }
                    }) { Text("Ekstrak") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        is Dlg.Apk -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MenuBtn(Icons.Rounded.FolderOpen, "Buka isi (bongkar)") { dlg = null; go(Loc.Arc(d.f, "")) }
                    MenuBtn(Icons.Rounded.InstallMobile, "Pasang aplikasi") { dlg = null; ctx.installApk(d.f) }
                    MenuBtn(Icons.Rounded.Edit, "Tanda tangani") { dlg = Dlg.Sign(d.f) }
                    MenuBtn(Icons.Rounded.Unarchive, "Ekstrak semua") { dlg = Dlg.Open(d.f) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        is Dlg.Sign -> {
            var ks by remember { mutableStateOf("") }
            var pw by remember { mutableStateOf("") }
            var al by remember { mutableStateOf("") }
            var v1 by remember { mutableStateOf(true) }
            var v2 by remember { mutableStateOf(true) }
            var v3 by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Tanda tangani APK") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Kosongkan path keystore untuk memakai kunci bawaan Arsipku.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(ks, { ks = it }, label = { Text("Path keystore (.p12 / .bks)") }, singleLine = true)
                        OutlinedTextField(pw, { pw = it }, label = { Text("Password keystore") }, singleLine = true)
                        OutlinedTextField(al, { al = it }, label = { Text("Alias (opsional)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(v1, { v1 = it }); Text("V1")
                            Checkbox(v2, { v2 = it }); Text("V2")
                            Checkbox(v3, { v3 = it }); Text("V3")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f
                        val out = File(a.parentFile, a.name.removeSuffix(".apk") + "-signed.apk")
                        val files = ctx.filesDir
                        val kp = ks.trim(); val pp = pw; val aa = al.trim()
                        val s1 = v1; val s2 = v2; val s3 = v3
                        dlg = null
                        work("Tersimpan: ${out.name}") {
                            val useDefault = kp.isEmpty()
                            Signer.sign(
                                a, out,
                                if (useDefault) Signer.defaultKeystore(files) else File(kp),
                                if (useDefault) Signer.PASS else pp, aa, s1, s2, s3
                            )
                        }
                    }) { Text("Tanda tangani") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        null -> {}
    }
}
