package com.arsipku

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedScroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)
    private var mode by mutableIntStateOf(2)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = getSharedPreferences("p", 0).getInt("theme", 2)
        setContent {
            AppTheme(mode) {
                if (granted) FileManager(listOf("🌓", "☀️", "🌙")[mode]) {
                    mode = (mode + 1) % 3
                    getSharedPreferences("p", 0).edit().putInt("theme", mode).apply()
                } else PermScreen { ask() }
            }
        }
    }

    override fun onResume() { super.onResume(); granted = hasAccess() }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun ask() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }
}

fun Context.installApk(f: File) {
    if (!packageManager.canRequestPackageInstalls()) {
        startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
    startActivity(
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private val Dark = darkColorScheme(
    primary = Color(0xFF6FE3B0), onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF0F5A44), onPrimaryContainer = Color(0xFFA6F5CF),
    secondary = Color(0xFF9FC4FF), onSecondary = Color(0xFF00315F),
    secondaryContainer = Color(0xFF1E4A7E), onSecondaryContainer = Color(0xFFD3E4FF),
    tertiary = Color(0xFFFFB870), onTertiary = Color(0xFF492900),
    tertiaryContainer = Color(0xFF6A3C00), onTertiaryContainer = Color(0xFFFFDCBB),
    background = Color(0xFF10131A), onBackground = Color(0xFFE3E4EC),
    surface = Color(0xFF10131A), onSurface = Color(0xFFE3E4EC),
    surfaceVariant = Color(0xFF2A2F3A), onSurfaceVariant = Color(0xFFC2C6D2),
    surfaceContainer = Color(0xFF181C25), surfaceContainerHigh = Color(0xFF1F2430),
    surfaceContainerHighest = Color(0xFF272C37), outline = Color(0xFF8C909C)
)

private val Light = lightColorScheme(
    primary = Color(0xFF006C4F), onPrimary = Color.White,
    primaryContainer = Color(0xFFA6F5CF), onPrimaryContainer = Color(0xFF002116),
    secondary = Color(0xFF2F5FA8), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3E4FF), onSecondaryContainer = Color(0xFF001B3E),
    tertiary = Color(0xFF8B5000), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDCBB), onTertiaryContainer = Color(0xFF2C1600),
    background = Color(0xFFF5F8F6), onBackground = Color(0xFF191C1B),
    surface = Color(0xFFF5F8F6), onSurface = Color(0xFF191C1B),
    surfaceVariant = Color(0xFFDDE5DF), onSurfaceVariant = Color(0xFF414943),
    surfaceContainer = Color(0xFFEBF0EC), surfaceContainerHigh = Color(0xFFE4EAE6),
    surfaceContainerHighest = Color(0xFFDDE4DF), outline = Color(0xFF717973)
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val cs = if (dark) Dark else Light
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = cs.background.toArgb()
        w.navigationBarColor = cs.background.toArgb()
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = cs,
        shapes = Shapes(
            small = RoundedCornerShape(16.dp), medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(36.dp)
        ),
        content = content
    )
}

@Composable
fun PermScreen(onAsk: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🗜️", fontSize = 64.sp)
            Spacer(Modifier.height(16.dp))
            Text("Arsipku butuh akses ke semua file", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("Untuk menjelajah, memindahkan, dan mengekstrak file.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAsk) { Text("Beri izin") }
        }
    }
}

sealed class Dlg {
    object NewFolder : Dlg()
    object Delete : Dlg()
    object Compress : Dlg()
    class Open(val f: File) : Dlg()
    class Apk(val f: File) : Dlg()
    class Sign(val f: File) : Dlg()
}

fun sizeText(b: Long): String {
    if (b < 1024) return "$b B"
    val u = listOf("KB", "MB", "GB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 2) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@Composable
fun Tile(f: File) {
    val c = MaterialTheme.colorScheme
    val (emoji, bg) = when {
        f.isDirectory -> "📁" to c.tertiaryContainer
        f.name.endsWith(".apk", true) -> "🤖" to c.primaryContainer
        FileOps.isArchive(f) -> "🗜️" to c.secondaryContainer
        else -> "📄" to c.surfaceVariant
    }
    Box(Modifier.size(48.dp).background(bg, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
        Text(emoji, fontSize = 24.sp)
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FileManager(themeIcon: String, onTheme: () -> Unit) {
    val ctx = LocalContext.current
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember { mutableStateOf(root) }
    var reload by remember { mutableIntStateOf(0) }
    val list = remember(dir, reload) {
        (dir.listFiles() ?: emptyArray()).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    var sel by remember { mutableStateOf(setOf<File>()) }
    var clip by remember { mutableStateOf(listOf<File>()) }
    var cut by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val cs = MaterialTheme.colorScheme

    fun work(ok: String, job: () -> Unit) {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            busy = false; reload++; sel = emptySet()
            snack.showSnackbar(r.exceptionOrNull()?.let { "Gagal: ${it.message}" } ?: ok)
        }
    }

    BackHandler(enabled = sel.isNotEmpty() || dir != root) {
        if (sel.isNotEmpty()) sel = emptySet() else dir = dir.parentFile ?: root
    }

    Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            LargeTopAppBar(
                title = { Text(if (sel.isEmpty()) "Arsipku" else "${sel.size} dipilih") },
                navigationIcon = {
                    if (sel.isNotEmpty()) FilledTonalIconButton({ sel = emptySet() }) { Text("✕") }
                    else if (dir != root) FilledTonalIconButton({ dir = dir.parentFile ?: root }) { Text("←") }
                },
                actions = { IconButton(onClick = onTheme) { Text(themeIcon, fontSize = 22.sp) } },
                colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = cs.background, scrolledContainerColor = cs.surfaceContainer),
                scrollBehavior = scroll
            )
        },
        bottomBar = {
            if (sel.isNotEmpty() || clip.isNotEmpty()) {
                Surface(Modifier.padding(12.dp), shape = RoundedCornerShape(32.dp), color = cs.surfaceContainerHighest) {
                    Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val m = Modifier.weight(1f)
                        val pad = PaddingValues(horizontal = 4.dp)
                        if (sel.isNotEmpty()) {
                            FilledTonalButton({ clip = sel.toList(); cut = false; sel = emptySet() }, m, contentPadding = pad) { Text("Salin", fontSize = 12.sp) }
                            FilledTonalButton({ clip = sel.toList(); cut = true; sel = emptySet() }, m, contentPadding = pad) { Text("Pindah", fontSize = 12.sp) }
                            FilledTonalButton({ dlg = Dlg.Compress }, m, contentPadding = pad) { Text("ZIP", fontSize = 12.sp) }
                            FilledTonalButton({ dlg = Dlg.Delete }, m, contentPadding = pad) { Text("Hapus", fontSize = 12.sp) }
                        } else {
                            Button({
                                val c = clip; val mv = cut; val d = dir
                                clip = emptyList()
                                work("Selesai") { c.forEach { if (mv) FileOps.move(it, d) else FileOps.copy(it, d) } }
                            }, m) { Text("Tempel di sini (${clip.size})") }
                            OutlinedButton({ clip = emptyList() }, m) { Text("Batal") }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (sel.isEmpty() && clip.isEmpty()) ExtendedFloatingActionButton(
                onClick = { dlg = Dlg.NewFolder }, shape = RoundedCornerShape(28.dp),
                containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer
            ) { Text("＋ Folder") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            Surface(Modifier.padding(horizontal = 16.dp, vertical = 4.dp), shape = RoundedCornerShape(50), color = cs.surfaceContainerHigh) {
                Text(
                    "📍 " + dir.path.removePrefix(root.path).ifEmpty { "/" },
                    Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (list.isEmpty()) Text("Folder kosong", Modifier.padding(24.dp), color = cs.onSurfaceVariant)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.path }) { f ->
                    val on = f in sel
                    Surface(
                        shape = RoundedCornerShape(28.dp),
                        color = if (on) cs.primaryContainer else cs.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = {
                                when {
                                    sel.isNotEmpty() -> sel = if (on) sel - f else sel + f
                                    f.isDirectory -> dir = f
                                    f.name.endsWith(".apk", true) -> dlg = Dlg.Apk(f)
                                    FileOps.isArchive(f) -> dlg = Dlg.Open(f)
                                }
                            },
                            onLongClick = { sel = if (on) sel - f else sel + f }
                        )
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Tile(f)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(f.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.lastModified()))
                                Text(
                                    (if (f.isDirectory) "Folder" else sizeText(f.length())) + " • " + date,
                                    style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        Dlg.NewFolder -> {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Folder baru") },
                text = { OutlinedTextField(name, { name = it }, label = { Text("Nama folder") }, singleLine = true) },
                confirmButton = { TextButton(onClick = { val n = name.trim(); val t = dir; dlg = null; if (n.isNotEmpty()) work("Folder dibuat") { File(t, n).mkdirs() } }) { Text("Buat") } },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Hapus ${sel.size} item?") },
            text = { Text("Item yang dihapus tidak bisa dikembalikan.") },
            confirmButton = { TextButton(onClick = { val l = sel.toList(); dlg = null; work("Terhapus") { l.forEach { it.deleteRecursively() } } }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        Dlg.Compress -> {
            var name by remember { mutableStateOf(if (sel.size == 1) sel.first().nameWithoutExtension else "arsip") }
            var pass by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Kompres ke ZIP") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text("Nama arsip") }, singleLine = true)
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (opsional)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val l = sel.toList(); val out = File(dir, name.trim().ifEmpty { "arsip" } + ".zip"); val p = pass
                        dlg = null; work("Arsip dibuat") { FileOps.zip(l, out, p) }
                    }) { Text("Kompres") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        is Dlg.Open -> {
            var pass by remember { mutableStateOf("") }
            var newDir by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (jika ada)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(newDir, { newDir = it })
                            Text("Ekstrak ke folder baru")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f; val p = pass
                        val to = if (newDir) File(a.parentFile, a.name.substringBefore(".")) else a.parentFile!!
                        dlg = null; work("Selesai diekstrak") { FileOps.extract(a, to, p) }
                    }) { Text("Ekstrak") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        is Dlg.Apk -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalButton({ dlg = null; ctx.installApk(d.f) }, Modifier.fillMaxWidth()) { Text("📲 Pasang aplikasi") }
                    FilledTonalButton({ dlg = Dlg.Sign(d.f) }, Modifier.fillMaxWidth()) { Text("✍️ Tanda tangani") }
                    FilledTonalButton({ dlg = Dlg.Open(d.f) }, Modifier.fillMaxWidth()) { Text("🗜️ Ekstrak isi") }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        is Dlg.Sign -> {
            var ks by remember { mutableStateOf("") }
            var pw by remember { mutableStateOf("") }
            var al by remember { mutableStateOf("") }
            var v1 by remember { mutableStateOf(true) }
            var v2 by remember { mutableStateOf(true) }
            var v3 by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Tanda tangani APK") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Kosongkan path keystore untuk memakai kunci bawaan Arsipku.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(ks, { ks = it }, label = { Text("Path keystore (.p12 / .bks)") }, singleLine = true)
                        OutlinedTextField(pw, { pw = it }, label = { Text("Password keystore") }, singleLine = true)
                        OutlinedTextField(al, { al = it }, label = { Text("Alias (opsional)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(v1, { v1 = it }); Text("V1")
                            Checkbox(v2, { v2 = it }); Text("V2")
                            Checkbox(v3, { v3 = it }); Text("V3")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f
                        val out = File(a.parentFile, a.name.removeSuffix(".apk") + "-signed.apk")
                        val files = ctx.filesDir
                        val kp = ks.trim(); val pp = pw; val aa = al.trim()
                        val s1 = v1; val s2 = v2; val s3 = v3
                        dlg = null
                        work("Tersimpan: ${out.name}") {
                            val useDefault = kp.isEmpty()
                            Signer.sign(
                                a, out,
                                if (useDefault) Signer.defaultKeystore(files) else File(kp),
                                if (useDefault) Signer.PASS else pp, aa, s1, s2, s3
                            )
                        }
                    }) { Text("Tanda tangani") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        null -> {}
    }
}
