package com.arsipku

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.core.graphics.drawable.toBitmap
import androidx.core.view.WindowCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)
    private var mode by mutableIntStateOf(2)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = getSharedPreferences("p", 0).getInt("theme", 2)
        setContent {
            AppTheme(mode) {
                if (granted) FileManager(mode) {
                    mode = (mode + 1) % 3
                    getSharedPreferences("p", 0).edit().putInt("theme", mode).apply()
                } else PermScreen { ask() }
            }
        }
    }

    override fun onResume() { super.onResume(); granted = hasAccess() }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun ask() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }
}

fun Context.installApk(f: File) {
    if (!packageManager.canRequestPackageInstalls()) {
        startActivity(
            Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        return
    }
    val uri = FileProvider.getUriForFile(this, "$packageName.fp", f)
    startActivity(
        Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

private val Dark = darkColorScheme(
    primary = Color(0xFF6FE3B0), onPrimary = Color(0xFF00382A),
    primaryContainer = Color(0xFF0F5A44), onPrimaryContainer = Color(0xFFA6F5CF),
    secondary = Color(0xFF9FC4FF), onSecondary = Color(0xFF00315F),
    secondaryContainer = Color(0xFF1E4A7E), onSecondaryContainer = Color(0xFFD3E4FF),
    tertiary = Color(0xFFFFB870), onTertiary = Color(0xFF492900),
    tertiaryContainer = Color(0xFF6A3C00), onTertiaryContainer = Color(0xFFFFDCBB),
    background = Color(0xFF10131A), onBackground = Color(0xFFE3E4EC),
    surface = Color(0xFF10131A), onSurface = Color(0xFFE3E4EC),
    surfaceVariant = Color(0xFF2A2F3A), onSurfaceVariant = Color(0xFFC2C6D2),
    surfaceContainer = Color(0xFF181C25), surfaceContainerHigh = Color(0xFF1F2430),
    surfaceContainerHighest = Color(0xFF272C37), outline = Color(0xFF8C909C)
)

private val Light = lightColorScheme(
    primary = Color(0xFF006C4F), onPrimary = Color.White,
    primaryContainer = Color(0xFFA6F5CF), onPrimaryContainer = Color(0xFF002116),
    secondary = Color(0xFF2F5FA8), onSecondary = Color.White,
    secondaryContainer = Color(0xFFD3E4FF), onSecondaryContainer = Color(0xFF001B3E),
    tertiary = Color(0xFF8B5000), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDCBB), onTertiaryContainer = Color(0xFF2C1600),
    background = Color(0xFFF5F8F6), onBackground = Color(0xFF191C1B),
    surface = Color(0xFFF5F8F6), onSurface = Color(0xFF191C1B),
    surfaceVariant = Color(0xFFDDE5DF), onSurfaceVariant = Color(0xFF414943),
    surfaceContainer = Color(0xFFEBF0EC), surfaceContainerHigh = Color(0xFFE4EAE6),
    surfaceContainerHighest = Color(0xFFDDE4DF), outline = Color(0xFF717973)
)

@Composable
fun AppTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val cs = if (dark) Dark else Light
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = cs.background.toArgb()
        w.navigationBarColor = cs.background.toArgb()
        WindowCompat.getInsetsController(w, view).apply {
            isAppearanceLightStatusBars = !dark
            isAppearanceLightNavigationBars = !dark
        }
    }
    MaterialTheme(
        colorScheme = cs,
        shapes = Shapes(
            small = RoundedCornerShape(16.dp), medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(36.dp)
        ),
        content = content
    )
}

@Composable
fun PermScreen(onAsk: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Rounded.Archive, null, Modifier.size(72.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(16.dp))
            Text("Arsipku butuh akses ke semua file", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("Untuk menjelajah, memindahkan, dan mengekstrak file.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAsk) { Text("Beri izin") }
        }
    }
}

sealed class Dlg {
    object NewFolder : Dlg()
    object Delete : Dlg()
    object Compress : Dlg()
    object DataInfo : Dlg()
    object Pass : Dlg()
    class Open(val f: File) : Dlg()
    class Apk(val f: File) : Dlg()
    class Sign(val f: File) : Dlg()
}

class Clip(val from: Loc, val nodes: List<Node>, val cut: Boolean)

class AppItem(
    val label: String, val pkg: String, val apk: File, val splits: Boolean,
    val version: String, val system: Boolean, val icon: ImageBitmap?
)

private val df: DateFormat = DateFormat.getDateInstance(DateFormat.MEDIUM)

fun sizeText(b: Long): String {
    if (b < 1024) return "$b B"
    val u = listOf("KB", "MB", "GB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 2) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

fun workDir(): File =
    File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Arsipku").also { it.mkdirs() }

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    return pm.getInstalledApplications(0).map { ai ->
        val ver = runCatching { pm.getPackageInfo(ai.packageName, 0).versionName }.getOrNull() ?: ""
        AppItem(
            pm.getApplicationLabel(ai).toString(), ai.packageName, File(ai.sourceDir),
            (ai.splitSourceDirs?.size ?: 0) > 0, ver, (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
            runCatching { ai.loadIcon(pm).toBitmap(96, 96).asImageBitmap() }.getOrNull()
        )
    }.sortedBy { it.label.lowercase() }
}

fun parentOf(loc: Loc, root: File, safRoot: String?): Loc? = when (loc) {
    is Loc.Disk -> if (loc.dir == root) null else Loc.Disk(loc.dir.parentFile ?: root)
    is Loc.Arc -> if (loc.inner.isEmpty()) Loc.Disk(loc.file.parentFile ?: root) else {
        val up = loc.inner.trimEnd('/').substringBeforeLast('/', "")
        Loc.Arc(loc.file, if (up.isEmpty()) "" else "$up/")
    }
    is Loc.Saf -> if (loc.docId == safRoot || !loc.docId.contains('/')) Loc.Disk(root)
        else Loc.Saf(loc.tree, loc.docId.substringBeforeLast('/'))
}

fun loadNodes(ctx: Context, loc: Loc, cache: MutableMap<String, List<Entry>>, pass: String): List<Node> = when (loc) {
    is Loc.Disk -> (loc.dir.listFiles() ?: emptyArray()).map {
        Node(it.name, it.isDirectory, if (it.isDirectory) 0L else it.length(), it.lastModified(), it.path)
    }.sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    is Loc.Arc -> FileOps.children(cache.getOrPut(loc.file.path) { FileOps.list(loc.file, pass) }, loc.inner)
    is Loc.Saf -> Saf.list(ctx.contentResolver, loc.tree, loc.docId)
}

fun deleteNodes(ctx: Context, loc: Loc, nodes: List<Node>) {
    when (loc) {
        is Loc.Disk -> nodes.forEach { File(it.id).deleteRecursively() }
        is Loc.Arc -> {
            check(FileOps.isZipLike(loc.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            FileOps.editZip(loc.file, nodes.map { it.id }.toSet(), emptyMap(), ctx.filesDir)
        }
        is Loc.Saf -> nodes.forEach { Saf.delete(ctx.contentResolver, loc.tree, it) }
    }
}

fun transfer(ctx: Context, clip: Clip, dest: Loc, pass: String) {
    val from = clip.from
    val cr = ctx.contentResolver
    when {
        from is Loc.Disk && dest is Loc.Disk ->
            clip.nodes.forEach { val f = File(it.id); if (clip.cut) FileOps.move(f, dest.dir) else FileOps.copy(f, dest.dir) }
        from is Loc.Arc && dest is Loc.Disk -> {
            FileOps.extractFrom(from.file, pass, clip.nodes.map { it.id }.toSet(), from.inner, dest.dir)
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Saf && dest is Loc.Disk -> {
            clip.nodes.forEach { Saf.copyOut(cr, from.tree, it, dest.dir) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Disk && dest is Loc.Arc -> {
            check(FileOps.isZipLike(dest.file)) { "Arsip ini hanya bisa dibaca, tidak bisa diubah" }
            val adds = FileOps.collectAdds(clip.nodes.map { File(it.id) }, dest.inner)
            FileOps.editZip(dest.file, emptySet(), adds, ctx.filesDir)
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        from is Loc.Disk && dest is Loc.Saf -> {
            clip.nodes.forEach { Saf.copyIn(cr, dest.tree, dest.docId, File(it.id)) }
            if (clip.cut) deleteNodes(ctx, from, clip.nodes)
        }
        else -> throw IllegalStateException("Kombinasi sumber dan tujuan ini belum didukung")
    }
}

@Composable
fun Tile(name: String, dir: Boolean) {
    val c = MaterialTheme.colorScheme
    val (icon, bg, fg) = when {
        dir -> Triple(Icons.Rounded.Folder, c.tertiaryContainer, c.onTertiaryContainer)
        name.endsWith(".apk", true) -> Triple(Icons.Rounded.Android, c.primaryContainer, c.onPrimaryContainer)
        FileOps.isArcName(name) -> Triple(Icons.Rounded.Archive, c.secondaryContainer, c.onSecondaryContainer)
        else -> Triple(Icons.Rounded.Description, c.surfaceVariant, c.onSurfaceVariant)
    }
    Box(Modifier.size(48.dp).background(bg, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = fg)
    }
}

@Composable
fun Act(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    FilledTonalButton(onClick, modifier, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, Modifier.size(20.dp))
            Text(label, fontSize = 11.sp)
        }
    }
}

@Composable
fun MenuBtn(icon: ImageVector, text: String, onClick: () -> Unit) {
    FilledTonalButton(onClick, Modifier.fillMaxWidth()) {
        Icon(icon, null, Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text)
    }
}

@Composable
fun Chip(icon: ImageVector, text: String, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick, label = { Text(text) },
        leadingIcon = { Icon(icon, null, Modifier.size(18.dp)) },
        shape = RoundedCornerShape(16.dp)
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun NodeRow(n: Node, on: Boolean, modifier: Modifier, onClick: () -> Unit, onLong: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val bg by animateColorAsState(if (on) cs.primaryContainer else cs.surfaceContainerHigh, label = "bg")
    val info = remember(n) {
        (if (n.isDir) "Folder" else sizeText(n.size)) + (if (n.time > 0) " • " + df.format(Date(n.time)) else "")
    }
    Surface(
        shape = RoundedCornerShape(28.dp), color = bg,
        modifier = modifier.fillMaxWidth().combinedClickable(onClick = onClick, onLongClick = onLong)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Tile(n.name, n.isDir)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(n.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(info, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
            }
            AnimatedVisibility(on) { Icon(Icons.Rounded.CheckCircle, null, tint = cs.primary) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppItem>?>(null) }
    var sys by remember { mutableStateOf(false) }
    var pick by remember { mutableStateOf<AppItem?>(null) }
    val cs = MaterialTheme.colorScheme
    LaunchedEffect(Unit) { apps = withContext(Dispatchers.IO) { loadApps(ctx) } }
    BackHandler(onBack = onBack)

    fun run(ok: String, open: Boolean, job: () -> File) {
        scope.launch {
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            r.onSuccess { if (open) onOpen(it) else Toast.makeText(ctx, "$ok: Download/Arsipku/${it.name}", Toast.LENGTH_LONG).show() }
            r.onFailure { Toast.makeText(ctx, "Gagal: ${it.message}", Toast.LENGTH_LONG).show() }
        }
    }

    fun copyApk(a: AppItem): File {
        val f = File(workDir(), a.label.replace(Regex("[^A-Za-z0-9 _.-]"), "_") + ".apk")
        a.apk.copyTo(f, true)
        return f
    }

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = { Text("Aplikasi terpasang") },
                navigationIcon = { FilledTonalIconButton(onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) } },
                actions = { FilterChip(selected = sys, onClick = { sys = !sys }, label = { Text("Sistem") }); Spacer(Modifier.width(12.dp)) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background)
            )
        }
    ) { pad ->
        val list = apps
        if (list == null) {
            Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list.filter { sys || !it.system }, key = { it.pkg }) { a ->
                    Surface(
                        shape = RoundedCornerShape(28.dp), color = cs.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth().clickable { pick = a }
                    ) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            if (a.icon != null) Image(a.icon, null, Modifier.size(48.dp))
                            else Box(Modifier.size(48.dp))
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(a.label, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(a.pkg + if (a.version.isNotEmpty()) " • " + a.version else "", style = MaterialTheme.typography.bodySmall,
                                    color = cs.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
    }

    pick?.let { a ->
        AlertDialog(
            onDismissRequest = { pick = null }, title = { Text(a.label, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        a.pkg + (if (a.splits) "\nAplikasi split: hanya APK utama yang disalin." else "") +
                            "\nHasil clone harus dipasang setelah aplikasi aslinya di-uninstall (tanda tangan berbeda).",
                        style = MaterialTheme.typography.bodySmall
                    )
                    MenuBtn(Icons.Rounded.FolderOpen, "Bongkar (buka isi APK)") { pick = null; run("", true) { copyApk(a) } }
                    MenuBtn(Icons.Rounded.Archive, "Cadangkan APK") { pick = null; run("Tersimpan", false) { copyApk(a) } }
                    MenuBtn(Icons.Rounded.Edit, "Clone + tanda tangan sendiri") {
                        pick = null
                        val fd = ctx.filesDir
                        run("Tersimpan", false) {
                            val c = copyApk(a)
                            val out = File(c.parentFile, c.name.removeSuffix(".apk") + "-signed.apk")
                            Signer.sign(c, out, Signer.defaultKeystore(fd), Signer.PASS, "", true, true, true)
                            c.delete()
                            out
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { pick = null }) { Text("Batal") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FileManager(themeMode: Int, onTheme: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("p", 0) }
    val root = remember { Environment.getExternalStorageDirectory() }
    var loc by remember { mutableStateOf<Loc>(Loc.Disk(root)) }
    var nodes by remember { mutableStateOf(emptyList<Node>()) }
    var loading by remember { mutableStateOf(true) }
    var reload by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf(setOf<String>()) }
    var clip by remember { mutableStateOf<Clip?>(null) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(false) }
    var arcPass by remember { mutableStateOf("") }
    var safTree by remember { mutableStateOf<Uri?>(prefs.getString("saf", null)?.let { Uri.parse(it) }) }
    val cache = remember { HashMap<String, List<Entry>>() }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val scroll = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val cs = MaterialTheme.colorScheme
    val l = loc
    val safRoot = safTree?.let { DocumentsContract.getTreeDocumentId(it) }
    val up = parentOf(l, root, safRoot)
    val selNodes = nodes.filter { it.id in sel }

    fun go(n: Loc) { loc = n; sel = emptySet() }

    fun work(ok: String, job: () -> Unit) {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            busy = false; cache.clear(); reload++; sel = emptySet()
            snack.showSnackbar(r.exceptionOrNull()?.let { "Gagal: ${it.message}" } ?: ok)
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            val id = DocumentsContract.getTreeDocumentId(uri)
            if (id.startsWith("primary:Android/data")) {
                runCatching {
                    ctx.contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                    )
                }
                prefs.edit().putString("saf", uri.toString()).apply()
                safTree = uri
                go(Loc.Saf(uri, id))
            } else scope.launch { snack.showSnackbar("Pilih folder Android/data lalu tekan Gunakan folder ini") }
        }
    }

    fun openData() {
        val t = safTree
        if (t != null) go(Loc.Saf(t, DocumentsContract.getTreeDocumentId(t)))
        else if (Build.VERSION.SDK_INT >= 33) dlg = Dlg.DataInfo
        else picker.launch(Saf.initial)
    }

    LaunchedEffect(loc, reload) {
        loading = true
        val cur = loc; val pw = arcPass
        val r = withContext(Dispatchers.IO) { runCatching { loadNodes(ctx, cur, cache, pw) } }
        nodes = r.getOrDefault(emptyList())
        loading = false
        r.exceptionOrNull()?.let { snack.showSnackbar("Gagal membuka: ${it.message}") }
    }

    BackHandler(enabled = sel.isNotEmpty() || up != null) {
        if (sel.isNotEmpty()) sel = emptySet() else up?.let { go(it) }
    }

    if (apps) {
        AppsScreen(onBack = { apps = false; reload++ }, onOpen = { f -> apps = false; go(Loc.Arc(f, "")) })
    } else Scaffold(
        modifier = Modifier.nestedScroll(scroll.nestedScrollConnection),
        containerColor = cs.background,
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            LargeTopAppBar(
                title = {
                    Text(
                        when {
                            sel.isNotEmpty() -> "${sel.size} dipilih"
                            l is Loc.Arc -> l.file.name
                            l is Loc.Saf -> "Android/data"
                            else -> "Arsipku"
                        },
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    if (sel.isNotEmpty()) FilledTonalIconButton({ sel = emptySet() }) { Icon(Icons.Rounded.Close, null) }
                    else if (up != null) FilledTonalIconButton({ go(up) }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = onTheme) {
                        Icon(when (themeMode) { 0 -> Icons.Rounded.BrightnessAuto; 1 -> Icons.Rounded.LightMode; else -> Icons.Rounded.DarkMode }, null)
                    }
                },
                colors = TopAppBarDefaults.largeTopAppBarColors(containerColor = cs.background, scrolledContainerColor = cs.surfaceContainer),
                scrollBehavior = scroll
            )
        },
        bottomBar = {
            AnimatedVisibility(
                visible = sel.isNotEmpty() || clip != null,
                enter = slideInVertically { it } + fadeIn(), exit = slideOutVertically { it } + fadeOut()
            ) {
                Surface(Modifier.padding(12.dp), shape = RoundedCornerShape(32.dp), color = cs.surfaceContainerHighest) {
                    Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val m = Modifier.weight(1f)
                        val c = clip
                        if (sel.isNotEmpty()) {
                            Act(Icons.Rounded.ContentCopy, "Salin", m) { clip = Clip(l, selNodes, false); sel = emptySet() }
                            Act(Icons.Rounded.ContentCut, "Pindah", m) { clip = Clip(l, selNodes, true); sel = emptySet() }
                            if (l is Loc.Disk) Act(Icons.Rounded.Archive, "ZIP", m) { dlg = Dlg.Compress }
                            Act(Icons.Rounded.Delete, "Hapus", m) { dlg = Dlg.Delete }
                        } else if (c != null) {
                            Button({
                                val d = l; val pw = arcPass
                                clip = null
                                work("Selesai") { transfer(ctx, c, d, pw) }
                            }, m) { Text("Tempel di sini (${c.nodes.size})") }
                            OutlinedButton({ clip = null }, m) { Text("Batal") }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            AnimatedVisibility(
                visible = l is Loc.Disk && sel.isEmpty() && clip == null,
                enter = scaleIn() + fadeIn(), exit = scaleOut() + fadeOut()
            ) {
                ExtendedFloatingActionButton(
                    onClick = { dlg = Dlg.NewFolder },
                    icon = { Icon(Icons.Rounded.CreateNewFolder, null) },
                    text = { Text("Folder") },
                    shape = RoundedCornerShape(28.dp),
                    containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer
                )
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy || loading) LinearProgressIndicator(Modifier.fillMaxWidth()) else Spacer(Modifier.height(4.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip(Icons.Rounded.Storage, "Penyimpanan") { go(Loc.Disk(root)) }
                Chip(Icons.Rounded.FolderSpecial, "Android/data") { openData() }
                Chip(Icons.Rounded.Apps, "Aplikasi") { apps = true }
                if (l is Loc.Arc) {
                    Chip(Icons.Rounded.Unarchive, "Ekstrak semua") { dlg = Dlg.Open(l.file) }
                    Chip(Icons.Rounded.Lock, "Password") { dlg = Dlg.Pass }
                }
            }
            Surface(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), shape = RoundedCornerShape(50), color = cs.surfaceContainerHigh) {
                Row(Modifier.padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.LocationOn, null, Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        when (l) {
                            is Loc.Disk -> l.dir.path.removePrefix(root.path).ifEmpty { "/" }
                            is Loc.Arc -> "/" + l.inner
                            is Loc.Saf -> "/" + l.docId.removePrefix("primary:")
                        },
                        style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            if (l is Loc.Arc && l.file.name.endsWith(".apk", true)) {
                Text(
                    "Hapus atau tempel file di sini akan otomatis menandatangani ulang APK.",
                    Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
                )
            }
            if (!loading && nodes.isEmpty()) {
                val hint = if (l is Loc.Disk && Build.VERSION.SDK_INT >= 30 && l.dir.path.contains("/Android/data"))
                    "Android/data diblokir untuk akses biasa. Pakai tombol Android/data di atas." else "Kosong"
                Text(hint, Modifier.padding(24.dp), color = cs.onSurfaceVariant)
            }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(nodes, key = { it.id }) { n ->
                    NodeRow(
                        n, n.id in sel, Modifier.animateItem(),
                        onClick = {
                            when {
                                sel.isNotEmpty() -> sel = if (n.id in sel) sel - n.id else sel + n.id
                                n.isDir -> when (val c = l) {
                                    is Loc.Disk -> go(Loc.Disk(File(n.id)))
                                    is Loc.Arc -> go(Loc.Arc(c.file, n.id + "/"))
                                    is Loc.Saf -> go(Loc.Saf(c.tree, n.id))
                                }
                                l is Loc.Disk && n.name.endsWith(".apk", true) -> dlg = Dlg.Apk(File(n.id))
                                l is Loc.Disk && FileOps.isArcName(n.name) -> go(Loc.Arc(File(n.id), ""))
                                else -> sel = sel + n.id
                            }
                        },
                        onLong = { sel = if (n.id in sel) sel - n.id else sel + n.id }
                    )
                }
            }
        }
    }

    when (val d = dlg) {
        Dlg.NewFolder -> {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Folder baru") },
                text = { OutlinedTextField(name, { name = it }, label = { Text("Nama folder") }, singleLine = true) },
                confirmButton = {
                    TextButton(onClick = {
                        val n = name.trim(); val t = (l as? Loc.Disk)?.dir; dlg = null
                        if (n.isNotEmpty() && t != null) work("Folder dibuat") { File(t, n).mkdirs() }
                    }) { Text("Buat") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Hapus ${sel.size} item?") },
            text = { Text("Item yang dihapus tidak bisa dikembalikan.") },
            confirmButton = {
                TextButton(onClick = {
                    val ln = l; val nn = selNodes; dlg = null
                    work("Terhapus") { deleteNodes(ctx, ln, nn) }
                }) { Text("Hapus") }
            },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        Dlg.Compress -> {
            var name by remember { mutableStateOf(if (selNodes.size == 1) File(selNodes[0].id).nameWithoutExtension else "arsip") }
            var pass by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Kompres ke ZIP") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text("Nama arsip") }, singleLine = true)
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (opsional)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val files = selNodes.map { File(it.id) }
                        val out = File((l as? Loc.Disk)?.dir ?: root, name.trim().ifEmpty { "arsip" } + ".zip")
                        val p = pass
                        dlg = null; work("Arsip dibuat") { FileOps.zip(files, out, p) }
                    }) { Text("Kompres") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Pass -> {
            var p by remember { mutableStateOf(arcPass) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Password arsip") },
                text = { OutlinedTextField(p, { p = it }, label = { Text("Password") }, singleLine = true) },
                confirmButton = { TextButton(onClick = { arcPass = p; cache.clear(); reload++; dlg = null }) { Text("Simpan") } },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.DataInfo -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Android/data") },
            text = {
                Text(
                    "Android 13 ke atas memblokir akses folder ini lewat izin folder biasa. " +
                        "Akses penuh di versi itu butuh layanan shell (Shizuku, root, atau ADB nirkabel). " +
                        "Di Android 11-12 tombol ini langsung bekerja. Kamu tetap bisa mencoba."
                )
            },
            confirmButton = { TextButton(onClick = { dlg = null; picker.launch(Saf.initial) }) { Text("Coba izinkan") } },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Tutup") } }
        )
        is Dlg.Open -> {
            var pass by remember { mutableStateOf(arcPass) }
            var newDir by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (jika ada)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(newDir, { newDir = it })
                            Text("Ekstrak ke folder baru")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f; val p = pass
                        val to = if (newDir) File(a.parentFile, a.name.substringBefore(".")) else a.parentFile!!
                        dlg = null; work("Selesai diekstrak") { FileOps.extract(a, to, p) }
                    }) { Text("Ekstrak") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        is Dlg.Apk -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    MenuBtn(Icons.Rounded.FolderOpen, "Buka isi (bongkar)") { dlg = null; go(Loc.Arc(d.f, "")) }
                    MenuBtn(Icons.Rounded.InstallMobile, "Pasang aplikasi") { dlg = null; ctx.installApk(d.f) }
                    MenuBtn(Icons.Rounded.Edit, "Tanda tangani") { dlg = Dlg.Sign(d.f) }
                    MenuBtn(Icons.Rounded.Unarchive, "Ekstrak semua") { dlg = Dlg.Open(d.f) }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        is Dlg.Sign -> {
            var ks by remember { mutableStateOf("") }
            var pw by remember { mutableStateOf("") }
            var al by remember { mutableStateOf("") }
            var v1 by remember { mutableStateOf(true) }
            var v2 by remember { mutableStateOf(true) }
            var v3 by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Tanda tangani APK") },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Kosongkan path keystore untuk memakai kunci bawaan Arsipku.", style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(ks, { ks = it }, label = { Text("Path keystore (.p12 / .bks)") }, singleLine = true)
                        OutlinedTextField(pw, { pw = it }, label = { Text("Password keystore") }, singleLine = true)
                        OutlinedTextField(al, { al = it }, label = { Text("Alias (opsional)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(v1, { v1 = it }); Text("V1")
                            Checkbox(v2, { v2 = it }); Text("V2")
                            Checkbox(v3, { v3 = it }); Text("V3")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f
                        val out = File(a.parentFile, a.name.removeSuffix(".apk") + "-signed.apk")
                        val files = ctx.filesDir
                        val kp = ks.trim(); val pp = pw; val aa = al.trim()
                        val s1 = v1; val s2 = v2; val s3 = v3
                        dlg = null
                        work("Tersimpan: ${out.name}") {
                            val useDefault = kp.isEmpty()
                            Signer.sign(
                                a, out,
                                if (useDefault) Signer.defaultKeystore(files) else File(kp),
                                if (useDefault) Signer.PASS else pp, aa, s1, s2, s3
                            )
                        }
                    }) { Text("Tanda tangani") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        null -> {}
    }
}
