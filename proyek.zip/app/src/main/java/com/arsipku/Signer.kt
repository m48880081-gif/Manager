package com.arsipku

import com.android.apksig.ApkSigner
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Date

object Signer {
    const val PASS = "arsipku"

    fun defaultKeystore(dir: File): File {
        val f = File(dir, "arsipku.p12")
        if (f.exists()) return f
        val kp = KeyPairGenerator.getInstance("RSA").apply { initialize(2048) }.generateKeyPair()
        val name = X500Name("CN=Arsipku, O=Arsipku, C=ID")
        val now = System.currentTimeMillis()
        val b = JcaX509v3CertificateBuilder(
            name, BigInteger.valueOf(now), Date(now - 86400000L), Date(now + 36500L * 86400000L), name, kp.public
        )
        val cs = JcaContentSignerBuilder("SHA256withRSA").build(kp.private)
        val cert = JcaX509CertificateConverter().getCertificate(b.build(cs))
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("arsipku", kp.private, PASS.toCharArray(), arrayOf(cert))
        f.outputStream().use { ks.store(it, PASS.toCharArray()) }
        return f
    }

    private fun load(f: File, pw: CharArray): KeyStore {
        var last: Exception? = null
        for (t in listOf("PKCS12", "BKS")) {
            try {
                val k = KeyStore.getInstance(t)
                f.inputStream().use { k.load(it, pw) }
                return k
            } catch (e: Exception) { last = e }
        }
        throw IllegalArgumentException("Keystore gagal dibuka (cek password, format .p12/.bks): ${last?.message}")
    }

    fun sign(apk: File, out: File, ksFile: File, pass: String, alias: String, v1: Boolean, v2: Boolean, v3: Boolean) {
        val pw = pass.toCharArray()
        val ks = load(ksFile, pw)
        val al = alias.ifEmpty { ks.aliases().nextElement() }
        val key = ks.getKey(al, pw) as PrivateKey
        val cert = ks.getCertificate(al) as X509Certificate
        val cfg = ApkSigner.SignerConfig.Builder("ARSIPKU", key, listOf(cert)).build()
        out.delete()
        ApkSigner.Builder(listOf(cfg))
            .setInputApk(apk).setOutputApk(out)
            .setV1SigningEnabled(v1).setV2SigningEnabled(v2).setV3SigningEnabled(v3)
            .setCreatedBy("Arsipku")
            .build().sign()
    }
}
