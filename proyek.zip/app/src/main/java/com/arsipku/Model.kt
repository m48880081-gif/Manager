package com.arsipku

import android.net.Uri
import java.io.File

data class Node(val name: String, val isDir: Boolean, val size: Long, val time: Long, val id: String)
data class Entry(val path: String, val dir: Boolean, val size: Long, val time: Long)

sealed class Loc {
    data class Disk(val dir: File) : Loc()
    data class Arc(val file: File, val inner: String) : Loc()
    data class Saf(val tree: Uri, val docId: String) : Loc()
}
