package com.arsipku

import android.content.pm.PackageManager
import rikka.shizuku.Shizuku

enum class ShState { NOT_INSTALLED, NOT_RUNNING, NO_PERMISSION, READY }

object Shell {
    const val PKG = "moe.shizuku.privileged.api"

    private val listeners = HashMap<Any, Shizuku.OnRequestPermissionResultListener>()
    private val binderListeners = HashMap<Any, Pair<Shizuku.OnBinderReceivedListener, Shizuku.OnBinderDeadListener>>()

    fun installed(pm: PackageManager): Boolean = try { pm.getPackageInfo(PKG, 0); true } catch (e: Throwable) { false }

    fun state(pm: PackageManager): ShState = when {
        available() -> if (granted()) ShState.READY else ShState.NO_PERMISSION
        installed(pm) -> ShState.NOT_RUNNING
        else -> ShState.NOT_INSTALLED
    }

    // true = pengguna menolak permanen, izin harus diberikan manual lewat aplikasi Shizuku
    fun rationale(): Boolean = try { Shizuku.shouldShowRequestPermissionRationale() } catch (e: Throwable) { false }

    fun watch(key: Any, cb: () -> Unit) {
        val a = Shizuku.OnBinderReceivedListener { cb() }
        val b = Shizuku.OnBinderDeadListener { cb() }
        binderListeners[key] = a to b
        Shizuku.addBinderReceivedListener(a)
        Shizuku.addBinderDeadListener(b)
    }

    fun unwatch(key: Any) {
        binderListeners.remove(key)?.let {
            Shizuku.removeBinderReceivedListener(it.first)
            Shizuku.removeBinderDeadListener(it.second)
        }
    }

    fun available(): Boolean = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
    fun granted(): Boolean = try { Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (e: Throwable) { false }
    fun request(code: Int) { try { Shizuku.requestPermission(code) } catch (e: Throwable) { } }

    fun listen(key: Any, cb: (Boolean) -> Unit) {
        val l = Shizuku.OnRequestPermissionResultListener { _, r -> cb(r == PackageManager.PERMISSION_GRANTED) }
        listeners[key] = l
        Shizuku.addRequestPermissionResultListener(l)
    }

    fun unlisten(key: Any) {
        listeners.remove(key)?.let { Shizuku.removeRequestPermissionResultListener(it) }
    }

    private val newProc by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        ).also { it.isAccessible = true }
    }

    fun q(s: String) = "'" + s.replace("'", "'\\''") + "'"

    private fun run(cmd: String, merge: Boolean): Pair<Int, String> {
        val full = if (merge) "($cmd) 2>&1" else cmd
        val p = newProc.invoke(null, arrayOf("sh", "-c", full), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        val code = p.waitFor()
        p.destroy()
        return code to out
    }

    private fun ok(r: Pair<Int, String>) {
        if (r.first != 0) throw IllegalStateException(r.second.trim().take(200).ifEmpty { "Perintah gagal (kode ${r.first})" })
    }

    fun list(path: String): List<Node> {
        val (_, out) = run("cd ${q(path)} 2>/dev/null && stat -L -c '%F|%s|%Y|%n' * .[!.]* 2>/dev/null", false)
        val base = path.trimEnd('/')
        return out.lineSequence().filter { it.isNotBlank() }.mapNotNull { ln ->
            val f = ln.split('|', limit = 4)
            if (f.size < 4) null else {
                val name = f[3].substringAfterLast('/')
                val dir = f[0].startsWith("directory")
                Node(name, dir, if (dir) 0L else (f[1].toLongOrNull() ?: 0L), (f[2].toLongOrNull() ?: 0L) * 1000, "$base/$name")
            }
        }.toList().sortedWith(compareBy({ !it.isDir }, { it.name.lowercase() }))
    }

    fun cp(src: String, destDir: String) = ok(run("cp -r ${q(src)} ${q(destDir.trimEnd('/') + "/")}", true))
    fun mv(src: String, destDir: String) = ok(run("mv ${q(src)} ${q(destDir.trimEnd('/') + "/")}", true))
    fun rm(path: String) = ok(run("rm -rf ${q(path)}", true))
    fun mkdir(path: String) = ok(run("mkdir -p ${q(path)}", true))
}
