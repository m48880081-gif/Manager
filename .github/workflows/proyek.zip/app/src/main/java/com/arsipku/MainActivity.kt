package com.arsipku

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private var granted by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme {
                if (granted) FileManager() else PermScreen { ask() }
            }
        }
    }

    override fun onResume() { super.onResume(); granted = hasAccess() }

    private fun hasAccess() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun ask() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
        } else {
            requestPermissions(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE), 1)
        }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val cs = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> darkColorScheme()
        else -> lightColorScheme()
    }
    MaterialTheme(
        colorScheme = cs,
        shapes = Shapes(
            small = RoundedCornerShape(16.dp), medium = RoundedCornerShape(20.dp),
            large = RoundedCornerShape(28.dp), extraLarge = RoundedCornerShape(36.dp)
        ),
        content = content
    )
}

@Composable
fun PermScreen(onAsk: () -> Unit) {
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.padding(32.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🗜️", fontSize = 64.sp)
            Spacer(Modifier.height(16.dp))
            Text("Arsipku butuh akses ke semua file", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(8.dp))
            Text("Untuk menjelajah, memindahkan, dan mengekstrak file.", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(24.dp))
            Button(onClick = onAsk) { Text("Beri izin") }
        }
    }
}

sealed class Dlg {
    object NewFolder : Dlg()
    object Delete : Dlg()
    object Compress : Dlg()
    class Open(val f: File) : Dlg()
}

fun sizeText(b: Long): String {
    if (b < 1024) return "$b B"
    val u = listOf("KB", "MB", "GB")
    var v = b / 1024.0
    var i = 0
    while (v >= 1024 && i < 2) { v /= 1024; i++ }
    return "%.1f %s".format(v, u[i])
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FileManager() {
    val root = remember { Environment.getExternalStorageDirectory() }
    var dir by remember { mutableStateOf(root) }
    var reload by remember { mutableIntStateOf(0) }
    val list = remember(dir, reload) {
        (dir.listFiles() ?: emptyArray()).sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
    }
    var sel by remember { mutableStateOf(setOf<File>()) }
    var clip by remember { mutableStateOf(listOf<File>()) }
    var cut by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf<Dlg?>(null) }
    var busy by remember { mutableStateOf(false) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    fun work(ok: String, job: () -> Unit) {
        scope.launch {
            busy = true
            val r = withContext(Dispatchers.IO) { runCatching(job) }
            busy = false; reload++; sel = emptySet()
            snack.showSnackbar(r.exceptionOrNull()?.let { "Gagal: ${it.message}" } ?: ok)
        }
    }

    BackHandler(enabled = sel.isNotEmpty() || dir != root) {
        if (sel.isNotEmpty()) sel = emptySet() else dir = dir.parentFile ?: root
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        topBar = {
            TopAppBar(
                title = {
                    if (sel.isEmpty()) Column {
                        Text("Arsipku")
                        Text(dir.path, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else Text("${sel.size} dipilih")
                },
                navigationIcon = {
                    if (sel.isNotEmpty()) TextButton(onClick = { sel = emptySet() }) { Text("✕") }
                    else if (dir != root) TextButton(onClick = { dir = dir.parentFile ?: root }) { Text("←") }
                }
            )
        },
        bottomBar = {
            if (sel.isNotEmpty() || clip.isNotEmpty()) {
                Surface(Modifier.padding(12.dp), shape = RoundedCornerShape(28.dp), tonalElevation = 6.dp) {
                    Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val m = Modifier.weight(1f)
                        val pad = PaddingValues(horizontal = 4.dp)
                        if (sel.isNotEmpty()) {
                            FilledTonalButton({ clip = sel.toList(); cut = false; sel = emptySet() }, m, contentPadding = pad) { Text("Salin", fontSize = 12.sp) }
                            FilledTonalButton({ clip = sel.toList(); cut = true; sel = emptySet() }, m, contentPadding = pad) { Text("Pindah", fontSize = 12.sp) }
                            FilledTonalButton({ dlg = Dlg.Compress }, m, contentPadding = pad) { Text("ZIP", fontSize = 12.sp) }
                            FilledTonalButton({ dlg = Dlg.Delete }, m, contentPadding = pad) { Text("Hapus", fontSize = 12.sp) }
                        } else {
                            Button({
                                val c = clip; val mv = cut; val d = dir
                                clip = emptyList()
                                work("Selesai") { c.forEach { if (mv) FileOps.move(it, d) else FileOps.copy(it, d) } }
                            }, m) { Text("Tempel di sini (${clip.size})") }
                            OutlinedButton({ clip = emptyList() }, m) { Text("Batal") }
                        }
                    }
                }
            }
        },
        floatingActionButton = {
            if (sel.isEmpty() && clip.isEmpty()) ExtendedFloatingActionButton(onClick = { dlg = Dlg.NewFolder }) { Text("＋ Folder") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (list.isEmpty()) Text("Folder kosong", Modifier.padding(24.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyColumn(contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(list, key = { it.path }) { f ->
                    val on = f in sel
                    Surface(
                        shape = RoundedCornerShape(24.dp),
                        color = if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainerHigh,
                        modifier = Modifier.fillMaxWidth().combinedClickable(
                            onClick = {
                                when {
                                    sel.isNotEmpty() -> sel = if (on) sel - f else sel + f
                                    f.isDirectory -> dir = f
                                    FileOps.isArchive(f) -> dlg = Dlg.Open(f)
                                }
                            },
                            onLongClick = { sel = if (on) sel - f else sel + f }
                        )
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (f.isDirectory) "📁" else if (FileOps.isArchive(f)) "🗜️" else "📄", fontSize = 28.sp)
                            Spacer(Modifier.width(16.dp))
                            Column {
                                Text(f.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                val date = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(f.lastModified()))
                                Text(
                                    (if (f.isDirectory) "Folder" else sizeText(f.length())) + " • " + date,
                                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    when (val d = dlg) {
        Dlg.NewFolder -> {
            var name by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Folder baru") },
                text = { OutlinedTextField(name, { name = it }, label = { Text("Nama folder") }, singleLine = true) },
                confirmButton = { TextButton(onClick = { val n = name.trim(); val t = dir; dlg = null; if (n.isNotEmpty()) work("Folder dibuat") { File(t, n).mkdirs() } }) { Text("Buat") } },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        Dlg.Delete -> AlertDialog(
            onDismissRequest = { dlg = null }, title = { Text("Hapus ${sel.size} item?") },
            text = { Text("Item yang dihapus tidak bisa dikembalikan.") },
            confirmButton = { TextButton(onClick = { val l = sel.toList(); dlg = null; work("Terhapus") { l.forEach { it.deleteRecursively() } } }) { Text("Hapus") } },
            dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
        )
        Dlg.Compress -> {
            var name by remember { mutableStateOf(if (sel.size == 1) sel.first().nameWithoutExtension else "arsip") }
            var pass by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text("Kompres ke ZIP") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(name, { name = it }, label = { Text("Nama arsip") }, singleLine = true)
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (opsional)") }, singleLine = true)
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val l = sel.toList(); val out = File(dir, name.trim().ifEmpty { "arsip" } + ".zip"); val p = pass
                        dlg = null; work("Arsip dibuat") { FileOps.zip(l, out, p) }
                    }) { Text("Kompres") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        is Dlg.Open -> {
            var pass by remember { mutableStateOf("") }
            var newDir by remember { mutableStateOf(true) }
            AlertDialog(
                onDismissRequest = { dlg = null }, title = { Text(d.f.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(pass, { pass = it }, label = { Text("Password (jika ada)") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(newDir, { newDir = it })
                            Text("Ekstrak ke folder baru")
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = {
                        val a = d.f; val p = pass
                        val to = if (newDir) File(a.parentFile, a.name.substringBefore(".")) else a.parentFile!!
                        dlg = null; work("Selesai diekstrak") { FileOps.extract(a, to, p) }
                    }) { Text("Ekstrak") }
                },
                dismissButton = { TextButton(onClick = { dlg = null }) { Text("Batal") } }
            )
        }
        null -> {}
    }
}
